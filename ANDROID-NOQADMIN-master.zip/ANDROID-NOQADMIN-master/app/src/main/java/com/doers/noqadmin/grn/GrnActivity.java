package com.doers.noqadmin.grn;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.doers.noqadmin.AdminMain;
import com.doers.noqadmin.LoginActivity;
import com.doers.noqadmin.R;
import com.doers.noqadmin.TopUp;
import com.doers.noqadmin.adapter.expenseAdapter;
import com.doers.noqadmin.models.UserModel;
import com.doers.noqadmin.stockupdate.stockUpdate;
import com.doers.noqadmin.utils.ApiCall;
import com.doers.noqadmin.utils.CaptureActivityAnyOrientation;
import com.doers.noqadmin.utils.DBHelper;
import com.google.gson.Gson;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.leinardi.android.speeddial.SpeedDialActionItem;
import com.leinardi.android.speeddial.SpeedDialView;
import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialog;
import com.shashank.sony.fancydialoglib.FancyAlertDialogListener;
import com.shashank.sony.fancydialoglib.Icon;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class GrnActivity extends AppCompatActivity {
    DBHelper mydb;

    private static final int TRIGGER_AUTO_COMPLETE = 100;
    private static final long AUTO_COMPLETE_DELAY = 300;
    private Handler Prdhandler,Suphandler;
    private AutoProductAdapter PrdautoSuggestAdapter;
    private AutoSupplierAdapter SupautoSuggestAdapter;
    AppCompatAutoCompleteTextView PrdautoCompleteTextView,SupautoCompleteTextView;
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    List<GrnItemModel> grnitmlist;
    RecyclerView.Adapter<GrnItemAdapter.ViewHolder> mAdapter;
    TextView TXTGRN_SUPPLIER;
String STR_USERID,STR_SUPID,STR_WAREHOUSEID,STR_GRNPRDS;
ImageView BTN_SCAN;
    private String scanContent,scanFormat;
    private Boolean isscanned=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grnentry);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("GRN Entry");
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
//        SpeedDialView speedDialView = findViewById(R.id.fab_grnitemadd);
        recyclerView = (RecyclerView) findViewById(R.id.grnitems_list);
        PrdautoCompleteTextView =   findViewById(R.id.topbarproduct);
        SupautoCompleteTextView =   findViewById(R.id.topbarsupplier);
        TXTGRN_SUPPLIER =   findViewById(R.id.grnsupplierdet);
        BTN_SCAN = findViewById(R.id.btn_scan);

        mydb=new DBHelper(GrnActivity.this);

        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        ((LinearLayoutManager) layoutManager).setReverseLayout(true);
        ((LinearLayoutManager) layoutManager).setStackFromEnd(true);
        recyclerView.setLayoutManager(layoutManager);
        grnitmlist  = new ArrayList<>();

        UserModel userModel = new UserModel();
        userModel = mydb.getAllUsers();
        if(userModel.getUemail()==null){
        }else{
            STR_USERID=String.valueOf(userModel.getUid());
        }
        BTN_SCAN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentIntegrator scanIntegrator = new IntentIntegrator(GrnActivity.this);
                scanIntegrator.setPrompt("Scan");
                scanIntegrator.setBeepEnabled(true);
                //The following line if you want QR code
//                            scanIntegrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
                scanIntegrator.setCaptureActivity(CaptureActivityAnyOrientation.class);
                scanIntegrator.setOrientationLocked(false);
                scanIntegrator.setBarcodeImageEnabled(true);
                scanIntegrator.initiateScan();

            }
        });
        List<ProductModel> PrdstringList = new ArrayList<>();
        PrdautoSuggestAdapter = new AutoProductAdapter(GrnActivity.this,android.R.layout.simple_dropdown_item_1line,PrdstringList);
        PrdautoCompleteTextView.setThreshold(2);
        PrdautoCompleteTextView.setAdapter(PrdautoSuggestAdapter);
        PrdautoCompleteTextView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view,
                                            int position, long id) {
                        ProductModel cim = PrdautoSuggestAdapter.getItem(position);
                        String prd_name,prd_qty,prd_price,prd_barcode,prd_id;

                        prd_name = cim.getName();
                        prd_qty=cim.getQty();
                        prd_price=cim.getPrice();
                        prd_barcode=cim.getBarcode();
                        prd_id=cim.getId();

                        GrnItemModel newitm = new GrnItemModel(prd_id,prd_barcode,prd_name,prd_qty,prd_price);


                        boolean isnew = true;
                        if(grnitmlist.size()==0){
                            grnitmlist.add(newitm);
                            isnew = false;
                        }else{
                            for(int i = 0; i < grnitmlist.size(); i++)
                            {
                                if(Double.parseDouble(grnitmlist.get(i).getPrd_id()) == Double.parseDouble(newitm.prd_id)){
                                    isnew = false;
                                }
                            }
                        }
                        if(isnew)
                        {
                            grnitmlist.add(newitm);
                        }
                        mAdapter = new GrnItemAdapter(GrnActivity.this, grnitmlist);
                        recyclerView.setAdapter(mAdapter);
                        mAdapter.notifyDataSetChanged();
                        PrdautoCompleteTextView.setText("");
                    }
                });

        PrdautoCompleteTextView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int
                    count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                  }
            @Override
            public void afterTextChanged(Editable s) {
                if(s.toString().length()>3){
                    Prdhandler.removeMessages(TRIGGER_AUTO_COMPLETE);
                Prdhandler.sendEmptyMessageDelayed(TRIGGER_AUTO_COMPLETE,
                        AUTO_COMPLETE_DELAY);
                }
            }
        });

        Prdhandler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                if (msg.what == TRIGGER_AUTO_COMPLETE) {
                    if (!TextUtils.isEmpty(PrdautoCompleteTextView.getText())) {
                        if(PrdautoCompleteTextView.getText().toString().length()>3){

                            Log.i("PRDINPUT: ",PrdautoCompleteTextView.getText().toString());
                            getproduct(PrdautoCompleteTextView.getText().toString());
                    }}
                }
                return false;
            }
        });
        List<supplierModel> supstringList = new ArrayList<>();
        SupautoSuggestAdapter = new AutoSupplierAdapter(GrnActivity.this,android.R.layout.simple_dropdown_item_1line,supstringList);
        SupautoCompleteTextView.setThreshold(2);
        SupautoCompleteTextView.setAdapter(SupautoSuggestAdapter);
        SupautoCompleteTextView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view,
                                            int position, long id) {
                        supplierModel csm = SupautoSuggestAdapter.getItem(position);
                        TXTGRN_SUPPLIER.setText("From :\n"+csm.getAddress());
                        STR_SUPID= csm.getId();
                        STR_WAREHOUSEID="5";
                    }
                });

        SupautoCompleteTextView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int
                    count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                if(s.toString().length()>3){
                Suphandler.removeMessages(TRIGGER_AUTO_COMPLETE);
                Suphandler.sendEmptyMessageDelayed(TRIGGER_AUTO_COMPLETE,
                        AUTO_COMPLETE_DELAY);}
            }
        });

        Suphandler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                if (msg.what == TRIGGER_AUTO_COMPLETE) {
                    if (!TextUtils.isEmpty(SupautoCompleteTextView.getText())) {
                        if (!SupautoCompleteTextView.getText().toString().contains(" - ")) {
                            getsupplier(SupautoCompleteTextView.getText().toString());

                        }
                    }
                }
                return false;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult scanningResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (scanningResult != null) {
            if (scanningResult.getContents() != null) {
                scanContent = scanningResult.getContents();
                scanFormat = scanningResult.getFormatName();
                isscanned=true;
                PrdautoCompleteTextView.setText(scanContent);
            }


        }else{
            Toast.makeText(this,"Nothing scanned",Toast.LENGTH_SHORT).show();
        }
    }

    public void getproduct(String query){
        Log.i("PARAMETER : ",query);

        String url = "http://noqapp.in/noq/prod/api/getproducts/";

        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i
                        Log.i("VALUE",response.toString());
                        try {
                            JSONArray jaarr = new JSONArray(response);
                            List<ProductModel> PrdstringList = new ArrayList<>();
                            for(int i=0;i<jaarr.length();i++){
                                JSONObject responseObject = jaarr.getJSONObject(i);
                                String id, name, price, qty,barcode;

                                id=responseObject.getString("product_id");
                                name=responseObject.getString("name");
                                price=responseObject.getString("purchase_price");
                                barcode=responseObject.getString("barcode");
                                qty="1";
                                PrdstringList.add(new ProductModel(id, name,qty, price, barcode));


                            }
                            PrdautoSuggestAdapter = new AutoProductAdapter(GrnActivity.this, android.R.layout.simple_dropdown_item_1line, PrdstringList);
                            PrdautoCompleteTextView.setThreshold(2);
                            PrdautoCompleteTextView.setAdapter(PrdautoSuggestAdapter);
                            PrdautoSuggestAdapter.notifyDataSetChanged();
                            if(isscanned){
                                PrdautoCompleteTextView.setSelection(0);
                                ProductModel cim = PrdautoSuggestAdapter.getItem(0);
                                String prd_name,prd_qty,prd_price,prd_barcode,prd_id;
                                prd_name = cim.getName();
                                prd_qty=cim.getQty();
                                prd_price=cim.getPrice();
                                prd_barcode=cim.getBarcode();
                                prd_id=cim.getId();
                                GrnItemModel newitm = new GrnItemModel(prd_id,prd_barcode,prd_name,prd_qty,prd_price);

                                boolean isnew = true;
                                if(grnitmlist.size()==0){
                                    grnitmlist.add(newitm);
                                    isnew = false;
                                }else{
                                    for(int i = 0; i < grnitmlist.size(); i++)
                                    {
                                        if(Double.parseDouble(grnitmlist.get(i).getPrd_id()) == Double.parseDouble(newitm.prd_id)){
                                            isnew = false;
                                        }
                                    }
                                }
                                if(isnew)
                                {
                                    grnitmlist.add(newitm);
                                }
                                mAdapter = new GrnItemAdapter(GrnActivity.this, grnitmlist);
                                recyclerView.setAdapter(mAdapter);
                                mAdapter.notifyDataSetChanged();
                                PrdautoCompleteTextView.setText("");
                            }
                            isscanned=false;
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs

                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map getParams()
            {
                Map params = new HashMap();

                return params;
            }
            @Override
            public byte[] getBody() throws AuthFailureError {
                return query.getBytes();
            }

        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));     //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);
        //creating a request queue
//        RequestQueue requestQueue = Volley.newRequestQueue(this);
//        //adding the string request to request queue
//        requestQueue.add(stringRequest);

    }
    public void getsupplier(String query){

        String url = "http://noqapp.in/noq/prod/api/getsupplier/";

        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i
                        Log.i("VALUE",response.toString());
                        try {
                            JSONArray jaarr = new JSONArray(response);
                            List<supplierModel> SupstringList = new ArrayList<>();
                            for(int i=0;i<jaarr.length();i++){
                                JSONObject responseObject = jaarr.getJSONObject(i);
                                String id, name, handle, address, status;


                                id=responseObject.getString("id");
                                name=responseObject.getString("name");
                                handle=responseObject.getString("handle");
                                address=responseObject.getString("address");
                                status=responseObject.getString("status");
                                SupstringList.add(new supplierModel(id, name, handle, address, status));


                            }
                            SupautoSuggestAdapter = new AutoSupplierAdapter(GrnActivity.this,android.R.layout.simple_dropdown_item_1line,SupstringList);
                            SupautoCompleteTextView.setThreshold(2);
                            SupautoCompleteTextView.setAdapter(SupautoSuggestAdapter);
                            SupautoSuggestAdapter.notifyDataSetChanged();

                        } catch (JSONException e) {

                            e.printStackTrace();
                        }



                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs

                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map getParams()
            {
                Map params = new HashMap();

                return params;
            }
            @Override
            public byte[] getBody() throws AuthFailureError {
                return query.getBytes();
            }

        };
        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.grn_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

         if (id == R.id.action_addgrn) {
             String json = new Gson().toJson(grnitmlist);
             STR_GRNPRDS = json;



             if(STR_USERID==null||STR_SUPID==null||STR_WAREHOUSEID==null||STR_USERID.isEmpty()||STR_USERID==""||STR_SUPID.isEmpty()||STR_SUPID==""||STR_WAREHOUSEID.isEmpty()||STR_WAREHOUSEID==""||STR_GRNPRDS.length()<1){
                 Toast.makeText(this, "Invalid Entry Kindly Try Again"+STR_GRNPRDS, Toast.LENGTH_SHORT).show();

             }else{
                 new FancyAlertDialog.Builder(GrnActivity.this)
                         .setTitle("NOQ GRN")
                         .setBackgroundColor(Color.parseColor("#0D0135"))  //Don't pass R.color.colorvalue
                         .setMessage("Are You Sure To Add GRN")
                         .setPositiveBtnBackground(Color.parseColor("#FF4081"))  //Don't pass R.color.colorvalue
                         .setPositiveBtnText("Add")
                         .setNegativeBtnText("Cancel")
                         .setIcon(R.drawable.ic_done, Icon.Visible)
                         .setAnimation(Animation.POP)
                         .isCancellable(false)
                         .OnNegativeClicked(new FancyAlertDialogListener() {
                             @Override
                             public void OnClick() {

                             }
                         }).OnPositiveClicked(new FancyAlertDialogListener() {
                     @Override
                     public void OnClick() {
                         addgrn();

                     }
                 })
                         .build();

             }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    public void addgrn(){
        final ProgressDialog dlg = new ProgressDialog(this);
        dlg.setMessage("Add GRN Processing...");
        dlg.setCancelable(false);
        dlg.show();



        String url = "http://noqapp.in/noq/prod/api/addgrn_viamobile/";

        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i
                        Log.i("VALUE",response.toString());
                        try {
                            JSONObject jobj = new JSONObject(response);
                            String STATUS = jobj.getString("status");
                            String msg = jobj.getString("msg");
                            try{ dlg.dismiss();}
                            catch (Exception dsf){

                            }

                            new FancyAlertDialog.Builder(GrnActivity.this)
                                    .setTitle("NOQ GRN")
                                    .setBackgroundColor(Color.parseColor("#0D0135"))  //Don't pass R.color.colorvalue
                                    .setMessage(msg)
                                    .setPositiveBtnBackground(Color.parseColor("#FF4081"))  //Don't pass R.color.colorvalue
                                    .setPositiveBtnText("Ok")
                                    .setNegativeBtnText("Cancel")
                                    .setIcon(R.drawable.ic_done, Icon.Visible)
                                    .setAnimation(Animation.POP)
                                    .isCancellable(false)
                                    .OnNegativeClicked(new FancyAlertDialogListener() {
                                        @Override
                                        public void OnClick() {
                                            if(Double.parseDouble(STATUS)==200){
                                                Intent setIntent = new Intent(GrnActivity.this, GrnActivity.class);
                                                setIntent.addCategory(Intent.CATEGORY_HOME);
                                                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                                startActivity(setIntent);
                                                finish();
                                            }else{
                                            }
                                        }
                                    }).OnPositiveClicked(new FancyAlertDialogListener() {
                                @Override
                                public void OnClick() {
                                    if(Double.parseDouble(STATUS)==200){
                                        Intent setIntent = new Intent(GrnActivity.this, GrnActivity.class);
                                        setIntent.addCategory(Intent.CATEGORY_HOME);
                                        setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(setIntent);
                                        finish();
                                    }else{
                                    }
                                }
                            })
                                    .build();


                        } catch (JSONException e) {
                            try{ dlg.dismiss();}
                            catch (Exception dsf){

                            }
                            e.printStackTrace();
                        }



                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        try{ dlg.dismiss();}
                        catch (Exception dsf){

                        }
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map getParams()
            {
                Map params = new HashMap();
                params.put("userid",STR_USERID);
                params.put("supid", STR_SUPID);
                params.put("whid", STR_WAREHOUSEID);
                params.put("grnlist", STR_GRNPRDS);


                return params;
            }

        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));     //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }

    @Override
    public void onBackPressed() {
        Log.d("CDA", "onBackPressed Called");
        Intent setIntent = new Intent(GrnActivity.this, LoginActivity.class);
        setIntent.addCategory(Intent.CATEGORY_HOME);
        setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(setIntent);
    }
}

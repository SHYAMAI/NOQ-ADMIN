package com.doers.noqadmin.fragments;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.doers.noqadmin.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class Dawntodusk extends Fragment {


    private TextView Todayprofit;
    private TextView Totalprofit;
    private TextView Todayordercount;
    private TextView Totalordercount;
    private TextView Todayordervalue;
    private TextView Totalordervalue;
    private TextView Avgordercount;
    private TextView Todayavgcartcount;
    private TextView Totalavgcartcount;
    private TextView Avgordervalue;
    private TextView Todayavgcartvalue;
    private TextView Totalavgcartvalue;
    String Todaydate;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_dawn, container, false);
        Todayprofit = (TextView) root.findViewById(R.id.adash_todayprofit);
        Totalprofit = (TextView) root.findViewById(R.id.adash_totalprofit);
        Todayordercount = (TextView) root.findViewById(R.id.adash_todayordercount);
        Totalordercount = (TextView) root.findViewById(R.id.adash_totalordercount);
        Todayordervalue = (TextView) root.findViewById(R.id.adash_todayordervalue);
        Totalordervalue = (TextView) root.findViewById(R.id.adash_totalordervalue);
        Avgordercount = (TextView) root.findViewById(R.id.adash_avgorderscount);
        Todayavgcartcount = (TextView) root.findViewById(R.id.adash_todayavgcartcount);
        Totalavgcartcount = (TextView) root.findViewById(R.id.adash_totalavgcartcount);
        Avgordervalue = (TextView) root.findViewById(R.id.adash_avgordersvalue);
        Todayavgcartvalue = (TextView) root.findViewById(R.id.adash_todayavgcartvalue);
        Totalavgcartvalue = (TextView) root.findViewById(R.id.adash_totalavgcartvalue);
        Date selectedDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        Todaydate = dateFormat.format(selectedDate);
        new LoadProfit().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        new LoadOrders().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

        return root;
    }


    @SuppressLint("StaticFieldLeak")
    public class LoadOrders extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(String... params) {

            String url = "http://noqapp.in/noq/prod/api/dashboard_data/";

            //creating a string request to send request to the url
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            //hiding the progressbar after completionLog.i

                            Log.i("VALUE",response.toString());

                            try {
                                JSONObject jarray = new JSONObject(response);

                                JSONObject jordercount = new JSONObject(jarray.getString("order_count"));
                                JSONObject jordervalue = new JSONObject(jarray.getString("order_value"));
                                JSONObject javgcount = new JSONObject(jarray.getString("avg_cart_size"));
                                JSONObject javgvalue = new JSONObject(jarray.getString("avg_cart_value"));

////                                String str_Todayprofit = jarray.getString("todayprofit").replace("null","0.00");
//                                String str_Todayprofit = "0.00";
//                                String str_Totalprofit = jarray.getString("profit_amount").replace("null","0.00");
                                String str_Todayordercount = jordercount.getString("t").replace("null","0");
                                String str_Totalordercount = jordercount.getString("a").replace("null","0");
                                String str_Todayordervalue = jordervalue.getString("t").replace("null","0.00");
                                String str_Totalordervalue = jordervalue.getString("a").replace("null","0.00");
                                String str_Avgordercount = jarray.getString("avg_ordercount").replace("null","0");
                                String str_Avgordervalue = jarray.getString("avg_orderamount").replace("null","0");

                                String str_Avgcartcounttoday = javgcount.getString("t").replace("null","0");
                                String str_Avgcartcounttotal = javgcount.getString("a").replace("null","0");
                                String str_Avgcartvaluetoday = javgvalue.getString("t").replace("null","0.00");
                                String str_Avgcartvaluetotal = javgvalue.getString("a").replace("null","0.00");

//                                Todayprofit.setText("₹ "+getdecimal(str_Todayprofit));
//                                Totalprofit.setText("₹ "+getdecimal(str_Totalprofit));
//                                Todayordercount.setText(str_Todayordercount);
//                                Totalordercount.setText(str_Totalordercount);
//                                Todayordervalue.setText("₹ "+getdecimal(str_Todayordervalue));
//                                Totalordervalue.setText("₹ "+getdecimal(str_Totalordervalue));
//                                Avgordercount.setText(str_Avgordercount);
//                                Avgordervalue.setText("₹ "+getdecimal(str_Avgordervalue));

                                Todayordercount.setText(String.valueOf(getFormatedAmount(Double.parseDouble(str_Todayordercount))));
                                Totalordercount.setText(String.valueOf(getFormatedAmount(Double.parseDouble(str_Totalordercount))));

                                Todayavgcartcount.setText(String.valueOf(getFormatedAmount(Double.parseDouble(str_Avgcartcounttoday))));
                                Totalavgcartcount.setText(String.valueOf(getFormatedAmount(Double.parseDouble(str_Avgcartcounttotal))));

                                Todayavgcartvalue.setText("₹ "+getdecimal(str_Avgcartvaluetoday));
                                Totalavgcartvalue.setText("₹ "+getdecimal(str_Avgcartvaluetotal));

                                Todayordervalue.setText("₹ "+getdecimal(str_Todayordervalue));
                                Totalordervalue.setText("₹ "+getdecimal(str_Totalordervalue));
                                Avgordercount.setText(String.valueOf(getFormatedAmount(Double.parseDouble(str_Avgordercount))));
                                Avgordervalue.setText("₹ "+getdecimal(str_Avgordervalue));

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            //displaying the error in toast if occurrs
                            try{ }
                            catch (Exception dsf){

                            }
                            Toast.makeText(Objects.requireNonNull(getActivity()).getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }){

                @Override
                protected Map getParams()
                {
                    Map params = new HashMap();
                    params.put("storeid","0");
                    params.put("date",Todaydate);

                    return params;
                }

            };
            //creating a request queue
            RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getActivity()).getApplicationContext());
            //adding the string request to request queue
            requestQueue.add(stringRequest);

            return "t";
        }

        @Override
        protected void onPostExecute(String bitmap) {
            super.onPostExecute(bitmap);

        }
    }

    @SuppressLint("StaticFieldLeak")
    public class LoadProfit extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(String... params) {

            String url = "http://noqapp.in/noq/prod/api/getproduct4_details/";

            //creating a string request to send request to the url
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            //hiding the progressbar after completionLog.i

                            Log.i("VALUE",response.toString());

                            try {
                                JSONObject jarray = new JSONObject(response);
                                JSONArray jprof = new JSONArray(jarray.getString("profit_today"));

                                JSONObject jprofobj =new JSONObject(jprof.getString(0));

//                                String str_Todayprofit = jarray.getString("todayprofit").replace("null","0.00");
                                String str_Todayprofit =jprofobj.getString("profit").replace("null","0.00");
                                String str_Totalprofit = jarray.getString("profit_amount").replace("null","0.00");
//                                String str_Todayordercount = jarray.getString("todayordercount").replace("null","0.00");
//                                String str_Totalordercount = jarray.getString("totalordercount").replace("null","0.00");
//                                String str_Todayordervalue = jarray.getString("todayordervalue").replace("null","0.00");
//                                String str_Totalordervalue = jarray.getString("totalordervalue").replace("null","0.00");
//                                String str_Avgordercount = jarray.getString("avgordercount").replace("null","0.00");
//                                String str_Avgordervalue = jarray.getString("avgordervalue").replace("null","0.00");

                                Todayprofit.setText("₹ "+getdecimal(str_Todayprofit));
                                Totalprofit.setText("₹ "+getdecimal(str_Totalprofit));
//                                Todayordercount.setText(str_Todayordercount);
//                                Totalordercount.setText(str_Totalordercount);
//                                Todayordervalue.setText("₹ "+getdecimal(str_Todayordervalue));
//                                Totalordervalue.setText("₹ "+getdecimal(str_Totalordervalue));
//                                Avgordercount.setText(str_Avgordercount);
//                                Avgordervalue.setText("₹ "+getdecimal(str_Avgordervalue));

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            //displaying the error in toast if occurrs
                            try{ }
                            catch (Exception dsf){

                            }
                            Toast.makeText(Objects.requireNonNull(getActivity()).getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }){

                @Override
                protected Map getParams()
                {
                    Map params = new HashMap();
                    params.put("storeid","0");
                    params.put("date",Todaydate);
                    return params;
                }

            };
            //creating a request queue
            RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getActivity()).getApplicationContext());
            //adding the string request to request queue
            requestQueue.add(stringRequest);

            return "t";
        }

        @Override
        protected void onPostExecute(String bitmap) {
            super.onPostExecute(bitmap);

        }
    }

    private String getFormatedAmount(Double amount){
        return NumberFormat.getNumberInstance(Locale.US).format(amount);
    }
    private void loaddash(){
        String url = "http://noqapp.in/noq/prod/api/admindash_app/";

        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i

                        Log.i("VALUE",response.toString());

                        try {
                            JSONObject jarray = new JSONObject(response);
//                            String str_Todayprofit = jarray.getString("todayprofit").replace("null","0.00");
//                            String str_Totalprofit = jarray.getString("totalprofit").replace("null","0.00");
                            String str_Todayordercount = jarray.getString("todayordercount").replace("null","0.00");
                            String str_Totalordercount = jarray.getString("totalordercount").replace("null","0.00");
                            String str_Todayordervalue = jarray.getString("todayordervalue").replace("null","0.00");
                            String str_Totalordervalue = jarray.getString("totalordervalue").replace("null","0.00");
                            String str_Avgordercount = jarray.getString("avgordercount").replace("null","0.00");
                            String str_Avgordervalue = jarray.getString("avgordervalue").replace("null","0.00");

//                            Todayprofit.setText("₹ "+getdecimal(str_Todayprofit));
//                            Totalprofit.setText("₹ "+getdecimal(str_Totalprofit));
                            Todayordercount.setText(String.valueOf(getFormatedAmount(Double.parseDouble(str_Todayordercount))));
                            Totalordercount.setText(String.valueOf(getFormatedAmount(Double.parseDouble(str_Totalordercount))));
                            Todayordervalue.setText("₹ "+getdecimal(String.valueOf(getFormatedAmount(Double.parseDouble(str_Todayordervalue)))));
                            Totalordervalue.setText("₹ "+getdecimal(String.valueOf(getFormatedAmount(Double.parseDouble(str_Totalordervalue)))));
                            Avgordercount.setText(String.valueOf(getFormatedAmount(Double.parseDouble(str_Avgordercount))));
                            Avgordervalue.setText("₹ "+getdecimal(String.valueOf(getFormatedAmount(Double.parseDouble(str_Avgordervalue)))));

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        try{ }
                        catch (Exception dsf){

                        }
                        Toast.makeText(Objects.requireNonNull(getActivity()).getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map getParams()
            {
                Map<String, String> params = new HashMap<String, String>();
                return params;
            }

        };
        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getActivity()).getApplicationContext());
        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }
    private String getdecimal(String data){
        System.out.println("string liters of petrol putting in preferences is "+data);
        Float litersOfPetrol=Float.parseFloat(data);
        DecimalFormat df = new DecimalFormat("#,##,##0.00");
        df.setMaximumFractionDigits(2);
        data = df.format(litersOfPetrol);
        System.out.println("liters of petrol before putting in editor : "+data);
        return data;
    }
}

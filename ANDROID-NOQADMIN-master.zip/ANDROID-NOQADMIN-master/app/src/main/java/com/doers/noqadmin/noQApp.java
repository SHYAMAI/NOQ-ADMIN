package com.doers.noqadmin;

import android.app.Application;
import android.content.Context;
import android.os.StrictMode;

import com.doers.noqadmin.utils.globalValue;

import io.realm.Realm;

public class noQApp extends Application {
    public static globalValue somevalue ;
    private static Context mContext;
    @Override
    public void onCreate() {
        super.onCreate();
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        singleton = this;
        mContext = this;
            Realm.init(mContext);
    }
    private static noQApp singleton;

    public globalValue getData(){
        return this.somevalue;
    }

    public void setData(globalValue d){
        this.somevalue=d;
    }

    public static noQApp getInstance() {
        return singleton;
    }
    public static Context getContext() {
        return mContext;
    }

}

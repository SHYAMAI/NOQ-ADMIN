package com.doers.noqadmin.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.doers.noqadmin.R;
import com.doers.noqadmin.models.orderitemsModel;

import java.util.List;

public class orderitemsadapter extends BaseAdapter {
    List<orderitemsModel> orderitemsList;

    Context context;
    private static LayoutInflater inflater=null;
    public orderitemsadapter(Context context, List<orderitemsModel> orderitemsList) {
        // TODO Auto-generated constructor stub
        this.context = context;
        this.orderitemsList = orderitemsList;
        inflater = ( LayoutInflater )context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return orderitemsList.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    public class Holder
    {
        TextView item_name,qty,rate,amount;
    }
    @SuppressLint("ViewHolder")
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        Holder holder=new Holder();
        View rowView=convertView;

        if (rowView == null) {
            rowView = inflater.inflate(R.layout.orderitems_lay, null);

            holder.item_name =(TextView) rowView.findViewById(R.id.itmname);
            holder.qty =(TextView) rowView.findViewById(R.id.itmqty);
            holder.rate =(TextView) rowView.findViewById(R.id.itmrate);
            holder.amount =(TextView) rowView.findViewById(R.id.itmtotal);

            rowView.setTag(holder);
        } else {
            holder = (Holder) rowView.getTag();
        }
        //getting the hero of the specified position
        orderitemsModel order = orderitemsList.get(position);

        holder.item_name.setText(order.getItm_name());
        holder.qty.setText(order.getItm_qty()+" Items");
        holder.rate.setText(order.getItm_rate());
        holder.amount.setText(order.getItm_tot());


        return rowView;
    }


}
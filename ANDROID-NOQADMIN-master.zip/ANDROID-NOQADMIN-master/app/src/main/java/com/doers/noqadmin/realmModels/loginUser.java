package com.doers.noqadmin.realmModels;

import android.util.Log;

import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import io.realm.Realm;
import io.realm.RealmList;
import io.realm.RealmModel;
import io.realm.RealmObject;
import io.realm.RealmResults;
import io.realm.Sort;
import io.realm.annotations.PrimaryKey;

public class loginUser implements RealmModel {
    private static final String TAG = loginUser.class.getSimpleName();

    // Keys in JSON response
    public static final String OBJECT_ID_JSON_KEY = "objectId";

    // Property name key
    public static final String ID_KEY = "id";
    public static final String IS_ACCEPTED_KEY = "isAccepted";
    public static final String CREATED_AT_KEY = "createdAt";

    @PrimaryKey
    private String id;
    private boolean isAccepted = true;
    private Date createdAt;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }



    public boolean isAccepted() {
        return isAccepted;
    }

    public void setAccepted(boolean accepted) {
        isAccepted = accepted;
    }


    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }


    public void mapFromJSON(JSONObject jsonObject) {
        try {
            this.id = jsonObject.getString(OBJECT_ID_JSON_KEY);

            this.isAccepted = jsonObject.getBoolean(IS_ACCEPTED_KEY);

            // Parse createdAt and convert UTC time to local time
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
            this.createdAt = simpleDateFormat.parse(jsonObject.getString("createdAt"));
        } catch (JSONException e) {
            Log.e(TAG, "Error in parsing loginUser.", e);
        } catch (ParseException e) {
            Log.e(TAG, "Error parsing createdAt.", e);
        }
    }

    public static void mapFromJSONArray(JSONArray jsonArray) {
        RealmList<loginUser> loginUsers = new RealmList<>();

        Realm realm = Realm.getDefaultInstance();
        realm.beginTransaction();

        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                JSONObject loginUserJson = jsonArray.getJSONObject(i);
                loginUser loginUser = new loginUser();
                loginUser.mapFromJSON(loginUserJson);
                loginUsers.add(loginUser);
            } catch (JSONException e) {
                Log.e(TAG, "Error in parsing loginUser.", e);
            }
        }

        realm.copyToRealmOrUpdate(loginUsers);
        realm.commitTransaction();
        realm.close();
    }

    public static void delete(String id) {
        Realm realm = Realm.getDefaultInstance();
        realm.beginTransaction();
        RealmResults<loginUser> loginUsers = realm.where(loginUser.class).equalTo(ID_KEY, id).findAll();
        if (loginUsers.size() > 0) {
            loginUsers.deleteFromRealm(0);
        }
        realm.commitTransaction();
        realm.close();
    }

    /**
     * @return all loginUsers by groupId
     */
    public static RealmList<loginUser> getAllloginUsersByGroupId(String groupId) {
        RealmList<loginUser> realmList = new RealmList<>();

        Realm realm = Realm.getDefaultInstance();
        RealmResults<loginUser> loginUsers = realm.where(loginUser.class)
                .findAll()
                .sort(CREATED_AT_KEY, Sort.DESCENDING);
        realm.close();

        for (loginUser loginUser : loginUsers) {
            if (loginUser.getId().equals(groupId)) {
                realmList.add(loginUser);
            }
        }

        return realmList;
    }

    /**
     * @return all accepted loginUsers by groupId
     */
    public static RealmList<loginUser> getAllAcceptedloginUsersByGroupId(String groupId) {
        RealmList<loginUser> realmList = new RealmList<>();

        Realm realm = Realm.getDefaultInstance();
        RealmResults<loginUser> loginUsers = realm.where(loginUser.class)
                .findAll()
                .sort(CREATED_AT_KEY, Sort.DESCENDING);
        realm.close();

        for (loginUser loginUser : loginUsers) {
            if (loginUser.getId().equals(groupId) && loginUser.isAccepted()) {
                realmList.add(loginUser);
            }
        }

        return realmList;
    }

    /**
     * @return all loginUsers by userId
     */
    public static RealmList<loginUser> getAllloginUsersByUserId(String userId) {
        RealmList<loginUser> realmList = new RealmList<>();

        Realm realm = Realm.getDefaultInstance();
        RealmResults<loginUser> loginUsers = realm.where(loginUser.class)
                .findAll()
                .sort(CREATED_AT_KEY, Sort.DESCENDING);
        realm.close();

        for (loginUser loginUser : loginUsers) {
            if (loginUser.getId().equals(userId)) {
                realmList.add(loginUser);
            }
        }

        return realmList;
    }

    /**
     * @param id
     * @return loginUser object if exist, otherwise return null.
     */
    public static @Nullable
    loginUser getloginUserById(String id) {
        Realm realm = Realm.getDefaultInstance();
        loginUser loginUser = realm.where(loginUser.class).equalTo(ID_KEY, id).findFirst();
        realm.close();

        return loginUser;
    }
}
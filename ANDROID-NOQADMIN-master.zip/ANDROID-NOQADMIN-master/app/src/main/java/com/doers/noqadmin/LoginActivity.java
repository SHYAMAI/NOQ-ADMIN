package com.doers.noqadmin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.doers.noqadmin.utils.DBHelper;
import com.doers.noqadmin.models.UserModel;
import com.libizo.CustomEditText;
import com.pitt.library.fresh.FreshDownloadView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.realm.annotations.Ignore;
import pub.devrel.easypermissions.EasyPermissions;

public class LoginActivity extends AppCompatActivity {
    private static final String TAG = "LoginActivity";
    private static final int REQUEST_SIGNUP = 0;

    CustomEditText _emailText;
    CustomEditText _passwordText;
     Button _loginButton;
String username,password;
    DBHelper mydb;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mydb=new DBHelper(LoginActivity.this);
        _emailText = findViewById(R.id.input_email);
         _passwordText = findViewById(R.id.input_password);
         _loginButton= findViewById (R.id.btn_login);
        _loginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                login();
            }
        });
        UserModel userModel = new UserModel();
        userModel = mydb.getAllUsers();
        if(userModel.getUemail()==null){

        }else{
            if(userModel.getUstatus().equalsIgnoreCase("loggedin")){
                if(userModel.getUtype().toLowerCase().contains("admin"))
                {
                    onAdminLoginSuccess();
                }else if(userModel.getUtype().toLowerCase().contains("manager")){
                    onManagerLoginSuccess();

                }
            }
        }
    }

    public void login() {
        Log.d(TAG, "Login");
        if (!validate()) {
            onLoginFailed();
            return;
        }
        _loginButton.setEnabled(false);
        username = _emailText.getText().toString();
        password = _passwordText.getText().toString();
        LOGIN();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_SIGNUP) {
            if (resultCode == RESULT_OK) {

                // TODO: Implement successful signup logic here
                // By default we just finish the Activity and log them in automatically
                this.finish();
            }
        }
    }

    @Override
    public void onBackPressed() {
        // disable going back to the AdminMain
        moveTaskToBack(true);
    }

    public void onManagerLoginSuccess() {
        _loginButton.setEnabled(true);
        Intent intent = new Intent(getApplicationContext(), ManagerMain.class);
        startActivityForResult(intent, REQUEST_SIGNUP);

        finish();
    }
    public void onAdminLoginSuccess() {
        _loginButton.setEnabled(true);
//        Intent intent = new Intent(getApplicationContext(), fridayMain.class);
        Intent intent = new Intent(getApplicationContext(), AdminMain.class);
        startActivityForResult(intent, REQUEST_SIGNUP);

        finish();
    }
    public void onLoginFailed() {
        Toast.makeText(getBaseContext(), "Login failed", Toast.LENGTH_LONG).show();

        _loginButton.setEnabled(true);
    }

    public boolean validate() {
        boolean valid = true;

        String email = _emailText.getText().toString();
        String password = _passwordText.getText().toString();

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            _emailText.setError("enter a valid email address");
            valid = false;
        } else {
            _emailText.setError(null);
        }

        if (password.isEmpty() || password.length() <= 1 || password.length() > 10) {
            _passwordText.setError("between 4 and 10 alphanumeric characters");
            valid = false;
        } else {
            _passwordText.setError(null);
        }

        return valid;
    }



    public void LOGIN(){
        final ProgressDialog dlg = new ProgressDialog(this);
        dlg.setMessage("Login Processing...");
        dlg.setCancelable(false);
        dlg.show();
        String url = "http://noqapp.in/noq/prod/api/manager_login/";
        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i
                        Log.i("VALUE",response.toString());
                        try {
                            JSONObject jobj = new JSONObject(response);
                            String STATUS = jobj.getString("status");
                            try{ dlg.dismiss();}
                            catch (Exception ignored){

                            }
                            if(STATUS.toLowerCase().equals("true")){
                                String data = jobj.getString("data");
                                JSONObject jon = new JSONObject(data);
                                String usertype =jon.getString("usertype");
                                String name =jon.getString("name");
                                String id =jon.getString("id");
                                String mobile_number =jon.getString("mobile_number");
                                String username =jon.getString("username");
                                String password =jon.getString("password");

                            long isinserted=mydb.addUser(Integer.parseInt(id),name,"",username,"loggedin",usertype);


                                if(usertype.toLowerCase().contains("admin"))
                                {
                                    onAdminLoginSuccess();
                                }else if(usertype.toLowerCase().contains("manager")){
                                    onManagerLoginSuccess();

                                }
                            }else{
                                onLoginFailed();
                            }



                        } catch (JSONException e) {
                            try{ dlg.dismiss();}
                            catch (Exception ignored){

                            }
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        try{ dlg.dismiss();}
                        catch (Exception ignored){

                        }
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map getParams()
            {
                Map<String, String> params = new HashMap<String, String>();
                params.put("username", username);
                params.put("password", password);

                return params;
            }

        };
        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }

}
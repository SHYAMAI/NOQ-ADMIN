package com.doers.noqadmin.grn;

public class supplierModel  {

    String id;
    String name;
    String handle;
    String address;
    String status;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHandle() {
        return handle;
    }

    public void setHandle(String handle) {
        this.handle = handle;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public supplierModel(String id, String name, String handle, String address, String status) {
        this.id = id;
        this.name = name;
        this.handle = handle;
        this.address = address;
        this.status = status;
    }
    // add this line
    @Override
    public String toString() {
        return getName();
    }
}
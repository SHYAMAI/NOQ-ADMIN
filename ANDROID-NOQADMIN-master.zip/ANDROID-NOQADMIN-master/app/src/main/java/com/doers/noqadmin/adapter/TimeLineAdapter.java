package com.doers.noqadmin.adapter;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.doers.noqadmin.R;
import com.doers.noqadmin.models.TimeLineModel;
import com.doers.noqadmin.models.orderitemsModel;
import com.github.vipulasri.timelineview.TimelineView;

import org.json.JSONObject;

import java.util.List;

public class TimeLineAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<TimeLineModel> timeLineModelList;
    private Activity context;

    public TimeLineAdapter(Activity context, List<TimeLineModel> timeLineModelList) {
        this.timeLineModelList = timeLineModelList;
        this.context = context;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_timeline_layout, parent, false);
        return new ViewHolder(view, viewType);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {


        TimeLineModel tlm = timeLineModelList.get(position);

                ((ViewHolder) holder).txt_ord_time.setText(tlm.getOrd_date()+" ");
                ((ViewHolder) holder).txt_ord_customer.setText(" -"+tlm.getOrd_customer());
                ((ViewHolder) holder).txt_ord_number.setText("#"+tlm.getOrd_id());
                ((ViewHolder) holder).txt_ord_status.setText(" -"+tlm.getOrd_paytype());
//                ((ViewHolder) holder).txt_ord_qty.setText("QTY :"+tlm.getOrd_id());
                ((ViewHolder) holder).txt_ord_amount.setText("\u20B9"+tlm.getOrd_amount());



   }

    @Override
    public int getItemViewType(int position) {
        return TimelineView.getTimeLineViewType(position, getItemCount());
    }

    @Override
    public int getItemCount() {
        return timeLineModelList.size();
    }

    private class ViewHolder extends RecyclerView.ViewHolder {

        TimelineView timelineView;
        TextView txt_ord_time,txt_ord_customer,txt_ord_number,txt_ord_status,txt_ord_qty,txt_ord_amount;

        ViewHolder(View itemView, int viewType) {
            super(itemView);
            timelineView = itemView.findViewById(R.id.timeline);
            txt_ord_time = itemView.findViewById(R.id.order_time);
            txt_ord_customer = itemView.findViewById(R.id.order_customer);
            txt_ord_number = itemView.findViewById(R.id.order_number);
            txt_ord_status = itemView.findViewById(R.id.order_status);
//            txt_ord_qty = itemView.findViewById(R.id.order_qty);
            txt_ord_amount = itemView.findViewById(R.id.order_amount);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    TimeLineModel tls = timeLineModelList.get(getAdapterPosition());

                    AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
                    LayoutInflater inflater = context.getLayoutInflater();
                    View dialogView = inflater.inflate(R.layout.orderitems_listlay, null);
                    dialogBuilder.setView(dialogView);
                    ListView Orderlistview = dialogView.findViewById(R.id.list_of_f);
                    TextView ordtitle = dialogView.findViewById(R.id.ordtitle);
                    TextView itmtotal = dialogView.findViewById(R.id.itmsamnt);
                    itmtotal.setText(tls.getOrd_amount());
                    TextView closedialog = dialogView.findViewById(R.id.closedialog);
                    ordtitle.setText(tls.getOrd_customer()+" - # "+tls.getOrd_id());
                    orderitemsadapter adapter = new orderitemsadapter(context, tls.getOrder_items());
                    Orderlistview.setAdapter(adapter);
                    final AlertDialog alertDialog = dialogBuilder.create();
                    alertDialog.show();
                    closedialog.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alertDialog.dismiss();
                        }
                    });
                }
            });

            timelineView.initLine(viewType);
        }
    }



}
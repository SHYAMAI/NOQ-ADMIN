package com.doers.noqadmin.utils;

public class globalValue {

    private String fromdate, todate, name;


    public String getFromdate() {
        return fromdate;
    }

    public void setFromdate(String fromdate) {
        this.fromdate = fromdate;
    }

    public String getTodate() {
        return todate;
    }

    public void setTodate(String todate) {
        this.todate = todate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public globalValue(String fromdate, String todate, String name) {
        this.fromdate = fromdate;
        this.name = name;
        this.todate = todate;

    }






}

package com.doers.noqadmin.models;

import java.io.Serializable;

public class userunsettledModel implements Serializable {
    String user_id;String user_name;String today_unsettled;String total_unsettled;


    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getToday_unsettled() {
        return today_unsettled;
    }

    public void setToday_unsettled(String today_unsettled) {
        this.today_unsettled = today_unsettled;
    }

    public String getTotal_unsettled() {
        return total_unsettled;
    }

    public void setTotal_unsettled(String total_unsettled) {
        this.total_unsettled = total_unsettled;
    }

    public userunsettledModel (String user_id, String user_name, String today_unsettled, String total_unsettled){
        this.user_id=user_id;
        this.user_name = user_name;
        this.today_unsettled = today_unsettled;
        this.total_unsettled = total_unsettled;
    }


}
package com.doers.noqadmin.fragments;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.doers.noqadmin.AdminMain;
import com.doers.noqadmin.R;
import com.doers.noqadmin.adapter.settlementAdapter;
import com.doers.noqadmin.models.userunsettledModel;
import com.doers.noqadmin.noQApp;
import com.doers.noqadmin.utils.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class Settlements extends Fragment {


    private TextView TXT_UNSETTLEDTODAY;
    private TextView TXT_UNSETTLEDTOTAL;
    private TextView TXT_SETTLEDTODAY;
    private TextView TXT_SETTLEDTOTAL,TXT_SETTLEDTHISMONTH;
    ImageView IMG_UNSETTLED_DETAILS;
    RecyclerView recyclerView;
    RecyclerView.Adapter<settlementAdapter.ViewHolder> mAdapter;
    RecyclerView.LayoutManager layoutManager;
    List<userunsettledModel> personUtilsList;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_three, container, false);
        TXT_UNSETTLEDTODAY = (TextView) root.findViewById(R.id.unsettled_today);
        TXT_UNSETTLEDTOTAL = (TextView) root.findViewById(R.id.unsettled_total);
        TXT_SETTLEDTODAY = (TextView) root.findViewById(R.id.settled_today);
        TXT_SETTLEDTOTAL = (TextView) root.findViewById(R.id.settled_total);
        TXT_SETTLEDTHISMONTH = (TextView) root.findViewById(R.id.settled_thismonth);
        IMG_UNSETTLED_DETAILS = (ImageView) root.findViewById(R.id.unsettled_detail);
        recyclerView = (RecyclerView) root.findViewById(R.id.user_unsettledlist);
        recyclerView.setVisibility(View.VISIBLE);
        Log.i("Settlements", noQApp.somevalue.getName());

        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        personUtilsList = new ArrayList<>();


        new LoadSettlement().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        recyclerView.setVisibility(View.GONE);
        IMG_UNSETTLED_DETAILS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recyclerView.setVisibility(View.VISIBLE);
//            new LoadUserwise().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            }
        });

        return root;
    }


    @SuppressLint("StaticFieldLeak")
    public class LoadSettlement extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(String... params) {

            String url = "http://noqapp.in/noq/prod/api/get_settledata/";

            //creating a string request to send request to the url
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            //hiding the progressbar after completionLog.i

                            Log.i("VALUE",response.toString());

                            try {
                                JSONObject iobj = new JSONObject(response);

                                String str_Todayunsettled = iobj.getString("today_unsettled").replace("null","0.00");
                                String str_Totalunsettled = iobj.getString("total_unsettled").replace("null","0.00");
                                String str_Todaysettled = iobj.getString("today_settled").replace("null","0.00");
                                String str_Totalsettled = iobj.getString("total_settled").replace("null","0.00");
                                String str_Thismonthsettled = iobj.getString("thismonth_settled").replace("null","0.00");

                                TXT_SETTLEDTHISMONTH.setText("₹ "+getdecimal(str_Thismonthsettled));
                                TXT_UNSETTLEDTODAY.setText("₹ "+getdecimal(str_Todayunsettled));
                                TXT_UNSETTLEDTOTAL.setText("₹ "+getdecimal(str_Totalunsettled));
                                TXT_SETTLEDTODAY.setText("₹ "+getdecimal(str_Todaysettled));
                                TXT_SETTLEDTOTAL.setText("₹ "+getdecimal(str_Totalsettled));

                                JSONArray jarray = new JSONArray(iobj.getString("unsettled_det"));

                                    for(int b=0;b<jarray.length();b++){

                                        JSONObject jobj =jarray.getJSONObject(b);
                                      String managerid=  jobj.getString("managerid");
                                      String name=  jobj.getString("name");
                                      String totalunsettled=  jobj.getString("totalunsettled").replace("null","0.00");
                                      String todayunsettled=  jobj.getString("todayunsettled").replace("null","0.00");

                                        personUtilsList.add(new userunsettledModel(managerid,name,todayunsettled,totalunsettled));

//                                        String str = jobj.getString("date_note");
//                                        List<String> elephantList = Arrays.asList(str.split(","));
//                                        String str2 = jobj.getString("unsettled");
//                                        List<String> elephantList2 = Arrays.asList(str2.split(","));
//                                        if(elephantList.contains("today")){
//                                            Double dd = Double.parseDouble(elephantList2.get(0))+Double.parseDouble(elephantList2.get(1));
//                                          personUtilsList.add(new userunsettledModel(jobj.getString("managerid"),jobj.getString("name"),elephantList2.get(0),String.valueOf(dd)));
//                                        }else{
//                                            personUtilsList.add(new userunsettledModel(jobj.getString("managerid"),jobj.getString("name"),"0.00",elephantList2.get(0)));
//                                        }
                                    }

                                mAdapter = new settlementAdapter(getActivity(), personUtilsList);
                                recyclerView.setAdapter(mAdapter);
                                mAdapter.notifyDataSetChanged();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            //displaying the error in toast if occurrs
                            Log.e("Errors:","dfgd");

                    }
                    }){

                @Override
                protected Map getParams()
                {
                    Map params = new HashMap();
                    params.put("fromdate",noQApp.somevalue.getFromdate());
                    params.put("todate",noQApp.somevalue.getTodate());
                    return params;
                }

            };
            VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);

//        //creating a request queue
//        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getActivity()).getApplicationContext());
//        //adding the string request to request queue
//        requestQueue.add(stringRequest);
            return "t";
        }

        @Override
        protected void onPostExecute(String bitmap) {
            super.onPostExecute(bitmap);

        }
    }

    private String getFormatedAmount(Double amount){
        return NumberFormat.getNumberInstance(Locale.US).format(amount);
    }

    private String getdecimal(String data){
        Float litersOfPetrol=Float.parseFloat(data);
        DecimalFormat df = new DecimalFormat("#,##,##0.00");
        df.setMaximumFractionDigits(2);
        data = df.format(litersOfPetrol);
        return data;
    }
}

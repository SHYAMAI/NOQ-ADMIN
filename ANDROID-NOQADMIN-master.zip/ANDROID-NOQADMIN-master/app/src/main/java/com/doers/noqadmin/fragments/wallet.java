package com.doers.noqadmin.fragments;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.doers.noqadmin.AdminMain;
import com.doers.noqadmin.R;
import com.doers.noqadmin.adapter.TimeLineAdapter;
import com.doers.noqadmin.adapter.newAdapter;
import com.doers.noqadmin.adapter.orderitemsadapter;
import com.doers.noqadmin.models.TimeLineModel;
import com.doers.noqadmin.models.orderitemsModel;
import com.doers.noqadmin.noQApp;
import com.doers.noqadmin.utils.VolleySingleton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class wallet extends Fragment {


    private TextView CASHTODAYTOP;
    private TextView CASHTOTALTOP;
    private TextView CARDTODAYTOP;
    private TextView CARDTOTALTOP;
    private TextView MOBILETODAYTOP;
    private TextView MOBILETOTALTOP;
    private TextView TODAYTOP;
    private TextView TOTALTOP;
    private TextView TODAYWEB;
    private TextView TOTALWEB;


    private TextView CARDTODAYUSE;
    private TextView CARDTOTALUSE;
    private TextView MOBILETODAYUSE;
    private TextView MOBILETOTALUSE;

    private TextView MOBILENTODAYUSE;
    private TextView MOBILENTOTALUSE;
    private TextView TODAYUSE;
    private TextView TOTALUSE,itmsamnt;

    RecyclerView recyclerView;
    RecyclerView.Adapter mAdapter;
    RecyclerView.LayoutManager layoutManager;

    List<orderitemsModel> personUtilsList;

    String fromday,today;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.fragment_two, container, false);
        CASHTODAYTOP = (TextView) root.findViewById(R.id.adash_todaycashtop);
        CASHTOTALTOP = (TextView) root.findViewById(R.id.adash_totalcashtop);
        CARDTODAYTOP = (TextView) root.findViewById(R.id.adash_todaycardtop);
        CARDTOTALTOP = (TextView) root.findViewById(R.id.adash_totalcardtop);
        MOBILETODAYTOP = (TextView) root.findViewById(R.id.adash_todaymobtop);
        MOBILETOTALTOP = (TextView) root.findViewById(R.id.adash_totalmobtop);
        TODAYTOP = (TextView) root.findViewById(R.id.adash_todaytop);
        TOTALTOP = (TextView) root.findViewById(R.id.adash_totaltop);
        TODAYWEB = (TextView) root.findViewById(R.id.adash_todayweb);
        TOTALWEB = (TextView) root.findViewById(R.id.adash_totalweb);
        TOTALWEB = (TextView) root.findViewById(R.id.adash_totalweb);
        itmsamnt = (TextView) root.findViewById(R.id.itmsamnt);

        Log.i("Wallet", noQApp.somevalue.getTodate());

        CARDTODAYUSE = (TextView) root.findViewById(R.id.adash_todaycarduse);
        CARDTOTALUSE = (TextView) root.findViewById(R.id.adash_totalcarduse);
        MOBILETODAYUSE = (TextView) root.findViewById(R.id.adash_todaymobuse);
        MOBILETOTALUSE = (TextView) root.findViewById(R.id.adash_totalmobuse);

        MOBILENTODAYUSE = (TextView) root.findViewById(R.id.adash_todaynonwuse);
        MOBILENTOTALUSE = (TextView) root.findViewById(R.id.adash_totalnonwuse);
        TODAYUSE = (TextView) root.findViewById(R.id.adash_todayuse);
        TOTALUSE = (TextView) root.findViewById(R.id.adash_totaluse);

        new LoadWallet().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

        recyclerView = (RecyclerView) root.findViewById(R.id.itemsrecyclerView);
        recyclerView.setHasFixedSize(true);

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        try {
            Date date1=new SimpleDateFormat("dd-MM-yyyy").parse(noQApp.somevalue.getFromdate());
            Date date2=new SimpleDateFormat("dd-MM-yyyy").parse(noQApp.somevalue.getTodate());
            fromday = dateFormat.format(date1);
            today = dateFormat.format(date2);
            new LoadItems().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } catch (ParseException e) {
            e.printStackTrace();
            fromday =noQApp.somevalue.getFromdate();
            today = noQApp.somevalue.getTodate();
            new LoadItems().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        }


        return root;



    }



    @SuppressLint("StaticFieldLeak")
    private class LoadWallet extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(String... params) {

            String url = "http://noqapp.in/noq/prod/api/getwallet_details/";

            //creating a string request to send request to the url
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            //hiding the progressbar after completionLog.i

                            Log.i("VALUE",response.toString());

                            try {
                                JSONObject jarray = new JSONObject(response);

                                JSONObject cash_topup = new JSONObject(jarray.getString("cash_topup"));
                                JSONObject card_topup = new JSONObject(jarray.getString("card_topup"));
                                JSONObject app_topup = new JSONObject(jarray.getString("app_topup"));
                                JSONObject total_topup = new JSONObject(jarray.getString("total_topup"));
                                JSONObject spend_card = new JSONObject(jarray.getString("spend_card"));
                                JSONObject spend_app = new JSONObject(jarray.getString("spend_app"));
                                JSONObject spend_wallet = new JSONObject(jarray.getString("spend_wallet"));
                                JSONObject spend_nonwallet = new JSONObject(jarray.getString("spend_nonwallet"));
                                JSONObject spend_web = new JSONObject(jarray.getString("spend_web"));


                                String str_CASHTODAYTOP = cash_topup.getString("t").replace("null","0.00");
                                String str_CASHTOTALTOP = cash_topup.getString("a").replace("null","0.00");
                                String str_CARDTODAYTOP = card_topup.getString("t").replace("null","0.00");
                                String str_CARDTOTALTOP = card_topup.getString("a").replace("null","0.00");
                                String str_MOBILETODAYTOP = app_topup.getString("t").replace("null","0.00");
                                String str_MOBILETOTALTOP = app_topup.getString("a").replace("null","0.00");
                                String str_TODAYTOP = total_topup.getString("t").replace("null","0.00");
                                String str_TOTALTOP = total_topup.getString("a").replace("null","0.00");

                                String str_CARDTODAYUSE = spend_app.getString("t").replace("null","0.00");
                                String str_CARDTOTALUSE = spend_app.getString("a").replace("null","0.00");
                                String str_MOBILETODAYUSE = spend_wallet.getString("t").replace("null","0.00");
                                String str_MOBILETOTALUSE = spend_wallet.getString("a").replace("null","0.00");

                                String str_MOBILENTODAYUSE = spend_nonwallet.getString("t").replace("null","0.00");
                                String str_MOBILENTOTALUSE = spend_nonwallet.getString("a").replace("null","0.00");

                                String str_WEBTODAYUSE = spend_web.getString("t").replace("null","0.00");
                                String str_WEBTOTALUSE = spend_web.getString("a").replace("null","0.00");

//                                String str_TODAYUSE = jarray.getString("t").replace("null","0.00");
                                String str_TODAYUSE = String.valueOf(Double.parseDouble(str_CARDTODAYUSE)+Double.parseDouble(str_MOBILETODAYUSE)+Double.parseDouble(str_MOBILENTODAYUSE)+Double.parseDouble(str_WEBTODAYUSE));
//                                String str_TOTALUSE = jarray.getString("a").replace("null","0.00");
                                String str_TOTALUSE = String.valueOf(Double.parseDouble(str_CARDTOTALUSE)+Double.parseDouble(str_MOBILETOTALUSE)+Double.parseDouble(str_MOBILENTOTALUSE)+Double.parseDouble(str_WEBTOTALUSE));

                                CASHTODAYTOP.setText("₹ "+getdecimal(str_CASHTODAYTOP));
                                CASHTOTALTOP.setText("₹ "+getdecimal(str_CASHTOTALTOP));
                                CARDTODAYTOP.setText("₹ "+getdecimal(str_CARDTODAYTOP));
                                CARDTOTALTOP.setText("₹ "+getdecimal(str_CARDTOTALTOP));
                                MOBILETODAYTOP.setText("₹ "+getdecimal(str_MOBILETODAYTOP));
                                MOBILETOTALTOP.setText("₹ "+getdecimal(str_MOBILETOTALTOP));
                                TODAYTOP.setText("₹ "+getdecimal(str_TODAYTOP));
                                TOTALTOP.setText("₹ "+getdecimal(str_TOTALTOP));

                                CARDTODAYUSE.setText("₹ "+getdecimal(str_CARDTODAYUSE));
                                CARDTOTALUSE.setText("₹ "+getdecimal(str_CARDTOTALUSE));
                                MOBILETODAYUSE.setText("₹ "+getdecimal(str_MOBILETODAYUSE));
                                MOBILETOTALUSE.setText("₹ "+getdecimal(str_MOBILETOTALUSE));

                                MOBILENTODAYUSE.setText("₹ "+getdecimal(str_MOBILENTODAYUSE));
                                MOBILENTOTALUSE.setText("₹ "+getdecimal(str_MOBILENTOTALUSE));
                                TODAYUSE.setText("₹ "+getdecimal(str_TODAYUSE));
                                TOTALUSE.setText("₹ "+getdecimal(str_TOTALUSE));
                                TODAYWEB.setText("₹ "+getdecimal(str_WEBTODAYUSE));
                                TOTALWEB.setText("₹ "+getdecimal(str_WEBTOTALUSE));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            //displaying the error in toast if occurrs
                            Log.e("Errors:","dfgd");}


                    }){

                @Override
                protected Map getParams()
                {

                    Map params = new HashMap();
                    params.put("storeid","0");
                    params.put("date",noQApp.somevalue.getFromdate());
                    params.put("fromdate",noQApp.somevalue.getFromdate());
                    params.put("todate",noQApp.somevalue.getTodate());
                    return params;
                }

            };
            VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);

//        //creating a request queue
//        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getActivity()).getApplicationContext());
//        //adding the string request to request queue
//        requestQueue.add(stringRequest);
            return "t";
        }

        @Override
        protected void onPostExecute(String bitmap) {
            super.onPostExecute(bitmap);

        }
    }
    @SuppressLint("StaticFieldLeak")
    private class LoadItems extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(String... params) {

            String url = "http://noqapp.in/noq/prod/api/get_itemsales/";

            //creating a string request to send request to the url
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            //hiding the progressbar after completionLog.i
                            Log.i("VALUE",response.toString());

                            layoutManager = new LinearLayoutManager(getActivity());

                            recyclerView.setLayoutManager(layoutManager);

                            personUtilsList = new ArrayList<>();

                            try {
                                JSONArray jarray = new JSONArray(response);
                                    Double tots = 0.00;
                                for (int i = 0; i < jarray.length(); i++) {

                                    JSONObject jobj = jarray.getJSONObject(i);



                                    String itm_name, itm_qty, itm_rate, itm_tot;

                                    itm_name = jobj.getString("name");
                                    itm_qty = jobj.getString("qty");
                                    itm_rate = jobj.getString("mrp");
                                    itm_tot = jobj.getString("total");
                                    tots = tots+Double.parseDouble(itm_tot);
                                    personUtilsList.add(new orderitemsModel(itm_name, itm_qty, getdecimal(itm_rate), getdecimal(itm_tot)));

                                }
                                itmsamnt.setText(getdecimal(String.valueOf(tots)));

                            }catch (Exception d){
                            }
                                    mAdapter = new newAdapter(getActivity(), personUtilsList);
                            recyclerView.setAdapter(mAdapter);
                            mAdapter.notifyDataSetChanged();
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            //displaying the error in toast if occurrs
                            Log.e("Errors:","dfgd");}
                    }){
                @Override
                protected Map getParams()
                {

                    Map params = new HashMap();
                    params.put("storeid","0");
                    params.put("date",noQApp.somevalue.getFromdate());
                    params.put("fromdate",fromday);
                    params.put("todate",today);

                    return params;
                }
            };
            VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);
//        //creating a request queue
//        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getActivity()).getApplicationContext());
//        //adding the string request to request queue
//        requestQueue.add(stringRequest);
            return "t";
        }

        @Override
        protected void onPostExecute(String bitmap) {
            super.onPostExecute(bitmap);

        }
    }
    private String getdecimal(String data){
        System.out.println("string liters of petrol putting in preferences is "+data);
        Float litersOfPetrol=Float.parseFloat(data);
        DecimalFormat df = new DecimalFormat("#,##,##0.00");
        df.setMaximumFractionDigits(2);
        data = df.format(litersOfPetrol);
        System.out.println("liters of petrol before putting in editor : "+data);
        return data;
    }
}

package com.doers.noqadmin;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.archit.calendardaterangepicker.customviews.DateRangeCalendarView;
import com.doers.noqadmin.adapter.TabAdapter;
import com.doers.noqadmin.fragments.Admin;
import com.doers.noqadmin.fragments.Settlements;
import com.doers.noqadmin.fragments.wallet;
import com.doers.noqadmin.grn.GrnActivity;
import com.doers.noqadmin.issuecard.issueCard;
import com.doers.noqadmin.stockupdate.stockUpdate;
import com.doers.noqadmin.utils.DBHelper;
import com.doers.noqadmin.models.UserModel;

import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.view.GravityCompat;
import androidx.appcompat.app.ActionBarDrawerToggle;

import android.view.MenuItem;

import com.doers.noqadmin.utils.globalValue;
import com.github.atzcx.appverupdater.AppVerUpdater;
import com.github.atzcx.appverupdater.UpdateErrors;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import com.nightonke.boommenu.BoomButtons.HamButton;
import com.nightonke.boommenu.BoomButtons.OnBMClickListener;
import com.nightonke.boommenu.BoomMenuButton;
import com.nightonke.boommenu.ButtonEnum;
import com.nightonke.boommenu.Piece.PiecePlaceEnum;
import com.pitt.library.fresh.FreshDownloadView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.view.Menu;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TimeZone;

import com.github.atzcx.appverupdater.callback.Callback;
import pub.devrel.easypermissions.EasyPermissions;

public class AdminMain extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,EasyPermissions.PermissionCallbacks {
    DBHelper mydb;
    TextView usernametext,mailtext,CurrentRange;
    private TabAdapter adapter;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private int[] tabIcons = {
            R.drawable.ic_group_black_24dp,
            R.drawable.ic_debit_card,
            R.drawable.ic_bank,
            R.drawable.dusk
    };
    DateRangeCalendarView calendarview;
    FreshDownloadView Progress;
    AlertDialog alertDialog;
    private String Fromdate,Todate;
    private static final int WRITE_REQUEST_CODE = 300;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Date today = new Date();
        Calendar cal = new GregorianCalendar();
        cal.setTime(today);
        cal.add(Calendar.DAY_OF_MONTH, 0);
        Date selectedDate = cal.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        Fromdate = dateFormat.format(selectedDate);
        Todate = dateFormat.format(selectedDate);
        noQApp.somevalue=new globalValue(Fromdate,Todate,"Today");
        StrictMode.VmPolicy.Builder builderq = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builderq.build());
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("NOQ ADMIN");
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        View navView =  navigationView.inflateHeaderView(R.layout.nav_header_main);
        CheckVerison();

        usernametext = navView.findViewById(R.id.user_nametext);
        mailtext = navView.findViewById(R.id.user_mailtext);
        viewPager = (ViewPager) findViewById(R.id.viewPager);
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        CurrentRange = (TextView) findViewById(R.id.currentrange);
        calendarview = findViewById(R.id.calendar);
        calendarview.setWeekOffset(0);
        Calendar startMonth = Calendar.getInstance();
        startMonth.add(Calendar.MONTH,-6);
        Calendar endMonth = Calendar.getInstance();
        endMonth.add(Calendar.MONTH,1);
        calendarview.setVisibleMonthRange(startMonth,endMonth);
        Calendar current = Calendar.getInstance();
        calendarview.setCurrentMonth(current);
        calendarview.setCalendarListener(new DateRangeCalendarView.CalendarListener() {
            @Override
            public void onFirstDateSelected(Calendar startDate) {
            }

            @Override
            public void onDateRangeSelected(Calendar startDate, Calendar endDate) {

                SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                Fromdate = dateFormat.format(startDate.getTime());
                Todate = dateFormat.format(endDate.getTime());
                noQApp.somevalue=new globalValue(Fromdate,Todate,"Yesterday");
                adapter.notifyDataSetChanged();
                CurrentRange.setText("Date: "+Fromdate+" to "+Todate);
                calendarview.setVisibility(View.GONE);
            }
        });
        CurrentRange.setText("Date: "+Fromdate);
        BoomMenuButton bmb = (BoomMenuButton) findViewById(R.id.bmb);
        assert bmb != null;
        bmb.setButtonEnum(ButtonEnum.Ham);
        HamButton.Builder builder1 = new HamButton.Builder()
                .subNormalText("To See the Yesterdays Data")
               .normalText("Yesterday")
                .listener(new OnBMClickListener() {
                    @Override
                    public void onBoomButtonClick(int index) {
                        Date today = new Date();
                        Calendar cal = new GregorianCalendar();
                        cal.setTime(today);
                        cal.add(Calendar.DAY_OF_MONTH, -1);
                        Date selectedDate = cal.getTime();
                        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                        Fromdate = dateFormat.format(selectedDate);
                        Todate = dateFormat.format(selectedDate);
                        Log.d("Date", Fromdate);
                        Log.d("Date", Todate);
                        // When the boom-button corresponding this builder is clicked.
                        Toast.makeText(AdminMain.this, Fromdate+"  "+Todate, Toast.LENGTH_SHORT).show();
                        noQApp.somevalue=new globalValue(Fromdate,Todate,"Yesterday");
                        adapter.notifyDataSetChanged();
                        CurrentRange.setText("Date: "+Fromdate);

                    }
                });
        bmb.addBuilder(builder1);
        HamButton.Builder builder2 = new HamButton.Builder()
                .subNormalText("Sunday to Today")
                .normalText("Week To Date")
                .listener(new OnBMClickListener() {
                    @Override
                    public void onBoomButtonClick(int index) {
                        Calendar cal = new GregorianCalendar();
                        Date selectedDate = cal.getTime();
                        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                        Todate = dateFormat.format(selectedDate);
                        Log.d("Date", Todate);

                        Calendar cal1 = Calendar.getInstance();
                        int dayOfTheWeek = cal1.get( Calendar.DAY_OF_WEEK );
                        cal1.add( Calendar.DAY_OF_WEEK, Calendar.SUNDAY - dayOfTheWeek );

                        Date selectedDate1 = cal1.getTime();
                        Fromdate = dateFormat.format(selectedDate1);
//                        Calendar cal1=Calendar.getInstance();
//                        cal1.add( Calendar.DAY_OF_WEEK, -(cal1.get(Calendar.DAY_OF_WEEK)-1));
//                        Fromdate = dateFormat.format(cal1.get(Calendar.DATE));

                        // When the boom-button corresponding this builder is clicked.
                        noQApp.somevalue=new globalValue(Fromdate,Todate,"Yesterday");
                        Toast.makeText(AdminMain.this, Fromdate+"  "+Todate, Toast.LENGTH_SHORT).show();
                        adapter.notifyDataSetChanged();
                        CurrentRange.setText("Date: "+Fromdate+" to "+Todate);
                    }
                });
        bmb.addBuilder(builder2);
        HamButton.Builder builder3 = new HamButton.Builder()
                .subNormalText("Last Sunday to Last Saturday")
                .normalText("Last Week")
                .listener(new OnBMClickListener() {
                    @Override
                    public void onBoomButtonClick(int index) {
                        Date date = new Date();
                        Calendar c = Calendar.getInstance();
                        c.setTime(date);
                        int i = c.get(Calendar.DAY_OF_WEEK) - c.getFirstDayOfWeek();
                        c.add(Calendar.DATE, -i - 7);
                        Date start = c.getTime();
                        c.add(Calendar.DATE, 6);
                        Date end = c.getTime();
                        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                        Todate = dateFormat.format(end);
                        Fromdate = dateFormat.format(start);
                        // When the boom-button corresponding this builder is clicked.
                        noQApp.somevalue=new globalValue(Fromdate,Todate,"Yesterday");
                        Toast.makeText(AdminMain.this, Fromdate+"  "+Todate, Toast.LENGTH_SHORT).show();
                        adapter.notifyDataSetChanged();
                        CurrentRange.setText("Date: "+Fromdate+" to "+Todate);

                    }
                });
        bmb.addBuilder(builder3);
        HamButton.Builder builder4 = new HamButton.Builder()
                .normalText("Month To Date")
                .subNormalText("This Month Date 1 to Today")
                .listener(new OnBMClickListener() {
                    @Override
                    public void onBoomButtonClick(int index) {
                        // When the boom-button corresponding this builder is clicked.
                        Calendar cal = new GregorianCalendar();
                        Date selectedDate = cal.getTime();
                        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                        Todate = dateFormat.format(selectedDate);
                        Log.d("Date", Todate);

                        Calendar instance = Calendar.getInstance();
                       int currentMonth = instance.get(Calendar.MONTH);
                        int currentYear = instance.get(Calendar.YEAR);

                        int month=currentMonth+1;

                        Fromdate="01-"+(month<10?("0"+month):(month))+"-"+currentYear;

//                        Calendar cal1=Calendar.getInstance();
//                        cal1.add( Calendar.DAY_OF_MONTH, -(cal1.get(Calendar.DAY_OF_MONTH)-1));
//                        Fromdate = dateFormat.format(cal1.get(Calendar.DATE));
                        // When the boom-button corresponding this builder is clicked.
                        noQApp.somevalue=new globalValue(Fromdate,Todate,"Yesterday");
                        Toast.makeText(AdminMain.this, Fromdate+"  "+Todate, Toast.LENGTH_SHORT).show();
                        adapter.notifyDataSetChanged();
                        CurrentRange.setText("Date: "+Fromdate+" to "+Todate);
                    }
                });
        bmb.addBuilder(builder4);
        HamButton.Builder builder5 = new HamButton.Builder()
                .normalText("Last Month")
                .subNormalText("Last Month Data")
                .listener(new OnBMClickListener() {
                    @Override
                    public void onBoomButtonClick(int index) {
                        Calendar aCalendar = Calendar.getInstance();
                    // add -1 month to current month
                        aCalendar.add(Calendar.MONTH, -1);
                    // set DATE to 1, so first date of previous month
                        aCalendar.set(Calendar.DATE, 1);

                        Date firstDateOfPreviousMonth = aCalendar.getTime();
                        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                        Fromdate = dateFormat.format(firstDateOfPreviousMonth);
                    // set actual maximum date of previous month
                        aCalendar.set(Calendar.DATE,     aCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));
                    //read it
                        Date lastDateOfPreviousMonth = aCalendar.getTime();
                        Todate = dateFormat.format(lastDateOfPreviousMonth);


                        // When the boom-button corresponding this builder is clicked.
                        noQApp.somevalue=new globalValue(Fromdate,Todate,"Yesterday");
                        Toast.makeText(AdminMain.this, Fromdate+"  "+Todate, Toast.LENGTH_SHORT).show();
                        adapter.notifyDataSetChanged();
                        CurrentRange.setText("Date: "+Fromdate+" to "+Todate);
                    }
                });
        bmb.addBuilder(builder5);
        HamButton.Builder builder = new HamButton.Builder()
                .normalText("Custom")
                .subNormalText("Choose Custom Date Ranges")
                .listener(new OnBMClickListener() {
                    @Override
                    public void onBoomButtonClick(int index) {
                        // When the boom-button corresponding this builder is clicked.
//                        Toast.makeText(AdminMain.this, "Clicked " + index, Toast.LENGTH_SHORT).show();
//                        adapter.notifyDataSetChanged();
                        calendarview.setVisibility(View.VISIBLE);
//                        CurrentRange.setText("Date: "+Fromdate+" to "+Todate);
                    }
                });
        bmb.addBuilder(builder);



        adapter = new TabAdapter(getSupportFragmentManager(), this);
        adapter.addFragment(new Admin(), "Order", tabIcons[0]);
        adapter.addFragment(new wallet(), "Sales", tabIcons[1]);
        adapter.addFragment(new Settlements(), "Settlement", tabIcons[2]);
//        adapter.addFragment(new Settlements(), "DawntoDusk", tabIcons[3]);
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
        highLightCurrentTab(0);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }@Override
            public void onPageSelected(int position) {
                highLightCurrentTab(position);
            }
            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
        mydb=new DBHelper(AdminMain.this);
        UserModel userModel = new UserModel();
        userModel = mydb.getAllUsers();
        if(userModel.getUemail()==null){
        }else{
            String name =String.valueOf(userModel.getUname());
            String email =String.valueOf(userModel.getUemail());
            usernametext.setText(name);
            mailtext.setText(email);
        }
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
    }
    private void highLightCurrentTab(int position) {
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            assert tab != null;
            tab.setCustomView(null);
            tab.setCustomView(adapter.getTabView(i));
        }
        TabLayout.Tab tab = tabLayout.getTabAt(position);
        assert tab != null;
        tab.setCustomView(null);
        tab.setCustomView(adapter.getSelectedTabView(position));
    }
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
    public interface CalendarListener {
        void onFirstDateSelected(Calendar startDate);
        void onDateRangeSelected(Calendar startDate, Calendar endDate);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_logout) {
            mydb.deleteUSer(1);
            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
            return true;
        } else if (id == R.id.action_refresh) {
            Date today = new Date();
            Calendar cal = new GregorianCalendar();
            cal.setTime(today);
            Date selectedDate = cal.getTime();
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
            Fromdate = dateFormat.format(selectedDate);
            Todate = dateFormat.format(selectedDate);
            noQApp.somevalue=new globalValue(Fromdate,Todate,"Today");
            adapter.notifyDataSetChanged();
            CurrentRange.setText("Date: "+Fromdate);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        if (id == R.id.nav_topup) {
            // Handle the camera action
            Intent intent = new Intent(getApplicationContext(), TopUp.class);
            startActivity(intent);
        } else if (id == R.id.nav_newuser) {
            Intent intent = new Intent(getApplicationContext(), userRegister.class);
            startActivity(intent);
        }
        else if (id == R.id.nav_expenses) {
            Intent intent = new Intent(getApplicationContext(), ExpenseActivity.class);
            startActivity(intent);
        }
        else if (id == R.id.nav_stockupdate) {
            Intent intent = new Intent(getApplicationContext(), stockUpdate.class);
            startActivity(intent);
        }
        else  if (id == R.id.nav_grn) {
            // Handle the camera action
            Intent intent = new Intent(getApplicationContext(), GrnActivity.class);
            startActivity(intent);
        }else if (id == R.id.nav_issuecard) {
            // Handle the camera action
            Intent intent = new Intent(getApplicationContext(), issueCard.class);
            startActivity(intent);
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    public void CheckUpdate() {
        // new LongOperation().execute("APKURL");

        if (CheckForSDCard.isSDCardPresent()) {

            //check if app has permission to write to the external storage.
            if (EasyPermissions.hasPermissions(AdminMain.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                //Get the URL entered
                new LongOperation().execute("http://noqapp.in/noqadmin.apk");

            } else {
                //If permission is not present request for the same.
                EasyPermissions.requestPermissions(AdminMain.this, getString(R.string.write_file), WRITE_REQUEST_CODE, Manifest.permission.READ_EXTERNAL_STORAGE);
            }


        } else {
            Toast.makeText(getApplicationContext(),
                    "SD Card not found", Toast.LENGTH_LONG).show();

        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, AdminMain.this);
    }

    @Override
    public void onPermissionsGranted(int requestCode, List<String> list) {
        // Some permissions have been granted
        // ...
        new LongOperation().execute("http://noqapp.in/noqadmin.apk");
    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> list) {
        // Some permissions have been denied
        // ...
    }
    public static class CheckForSDCard {
        //Method to Check If SD Card is mounted or not
        public static boolean isSDCardPresent() {
            if (Environment.getExternalStorageState().equals(

                    Environment.MEDIA_MOUNTED)) {
                return true;
            }
            return false;
        }
    }
//    private void update(){
//
//        appVerUpdater = new AppVerUpdater()
//                .setUpdateJSONUrl("http://noqapp.in/adminlog.json")
//                .setShowNotUpdated(true)
//                .setAlertDialogNotUpdateAvailableContent("New update Available !")
//                .setAlertDialogNotUpdateAvailableTitle("NOQ ADMIN")
//                .setAlertDialogUpdateAvailablePositiveText("Update")
//                .setAlertDialogUpdateAvailableNegativeText("Cancel")
//                .setViewNotes(true)
//                .setCallback(new Callback() {
//                    @Override
//                    public void onFailure(UpdateErrors error) {
//
//                        if (error == UpdateErrors.NETWORK_NOT_AVAILABLE) {
//                            Toast.makeText(AdminMain.this, "No internet connection.", Toast.LENGTH_LONG).show();
//                        }
//                        else if (error == UpdateErrors.ERROR_CHECKING_UPDATES) {
//                            Toast.makeText(AdminMain.this, "An error occurred while checking for updates.", Toast.LENGTH_LONG).show();
//                        }
//                        else if (error == UpdateErrors.ERROR_DOWNLOADING_UPDATES) {
//                            Toast.makeText(AdminMain.this, "An error occurred when downloading updates.", Toast.LENGTH_LONG).show();
//                        }
//                        else if (error == UpdateErrors.JSON_FILE_IS_MISSING) {
//                            Toast.makeText(AdminMain.this, "Json file is missing.", Toast.LENGTH_LONG).show();
//                        }
//                        else if (error == UpdateErrors.FILE_JSON_NO_DATA) {
//                            Toast.makeText(AdminMain.this, "The file containing information about the updates are empty.", Toast.LENGTH_LONG).show();
//                        }
//
//                    }
//
//                    @Override
//                    public void onDownloadSuccess() {
//                        // for example, record/reset license
//                    }
//
//                    @Override
//                    public void onUpdateChecked(boolean downloading) {
//                        // Happens after an update check, immediately after if update check was successful and there
//                        // were no dialogs, or, when an update dialog is presented and user explicitly dismissed the dialog.
//                        // "downloading" is true if user accepted the update
//                        // Typically used for resetting next update check time
//                    }
//                })
//                .setAlertDialogCancelable(true)
//                .build(this);
//
//    }



    @SuppressLint("StaticFieldLeak")
    private class LongOperation extends AsyncTask<String, Void, String> {
        //    private ProgressDialog progressDialog;
        @Override
        protected String doInBackground(String... params) {
            try {
                String extStorageDirectory = AdminMain.this.getExternalFilesDir(null).getAbsolutePath().toString();
                File folder = new File(extStorageDirectory, "noq");
                folder.mkdir();
                try {
                    File file1 = new File(folder, "noqadmin.apk");
                    file1.delete();
                }catch (Exception sf){

                }
                File file = new File(folder, "noqadmin." + "apk");
                try {
                    file.createNewFile();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                FileOutputStream f = new FileOutputStream(file);
                URL u = new URL(params[0]);
                HttpURLConnection c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("GET");
                //c.setDoOutput(true);
                c.connect();
                int lengthOfFile = c.getContentLength();

                InputStream in = c.getInputStream();
                byte[] buffer = new byte[1024];
                int len1 = 0;
                long total = 0;
                while ((len1 = in.read(buffer)) > 0) {
                    f.write(buffer, 0, len1);
                    total += len1;
                    float Percent = (total * 100) / lengthOfFile;

                    int ht = (int) Percent;
                    publishProgress(ht);
                }

                f.close();
            } catch (Exception e) {
                System.out.println("exception in DownloadFile: --------" + e.toString());
//                Progress.showDownloadError();
                e.printStackTrace();
            }
            return "Executed";
        }

        private void publishProgress(int s) {
            //   progressDialog.setProgress(s);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Progress.upDateProgress(s);
                    //Your code
                }
            });
        }

        @Override
        protected void onPostExecute(String result) {
            alertDialog.dismiss();
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(Uri.fromFile(new   File(AdminMain.this.getExternalFilesDir(null).getAbsolutePath().toString() + "/noq/" + "noqadmin.apk")), "application/vnd.android.package-archive");
                    startActivity(intent);       //Do something after 100ms
                }
            }, 2000);

        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            LayoutInflater li = LayoutInflater.from(AdminMain.this);
            View promptsView = li.inflate(R.layout.dialog_downloading, null);
            Progress= promptsView.findViewById (R.id.pitt);

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                    AdminMain.this);
            // set prompts.xml to alertdialog builder
            alertDialogBuilder.setView(promptsView);

            // set dialog message
            alertDialogBuilder
                    .setCancelable(false);
            // create alert dialog
            alertDialog = alertDialogBuilder.create();

            // show it
            alertDialog.show();
        }
    }

    public void CheckVerison(){
        String url = "http://noqapp.in/noq/prod/api/get_adminversion/";
        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.i("VALUE",response.toString());
                        try {
                            int versionCode = BuildConfig.VERSION_CODE;
                            JSONObject jobj = new JSONObject(response);
                            String VERSION = jobj.getString("version");

                            if(Double.parseDouble(VERSION)==Double.parseDouble(String.valueOf(versionCode))){
                                Log.i("Uptodate;",VERSION);
                            }else{
                                CheckUpdate();
                            }

                        } catch (JSONException e) {

                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs

                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map getParams()
            {
                Map<String, String> params = new HashMap<String, String>();
                params.put("version", "1.8");

                return params;
            }

        };
        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }

}

package com.doers.noqadmin.utils;

import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.android.volley.VolleyLog.TAG;

/**
 * Created by MG on 04-03-2018.
 */

public class ApiCall {
    private static ApiCall mInstance;
    private RequestQueue mRequestQueue;
    private static Context mCtx;

    public ApiCall(Context ctx) {
        mCtx = ctx;
        mRequestQueue = getRequestQueue();
    }

    public static synchronized ApiCall getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new ApiCall(context);
        }
        return mInstance;
    }

    public RequestQueue getRequestQueue() {
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(mCtx.getApplicationContext());
        }
        return mRequestQueue;
    }

    public <T> void addToRequestQueue(Request<T> req) {
        getRequestQueue().add(req);
    }

//    public static void getsupplier(Context ctx, String query, Response.Listener<String>
//            listener, Response.ErrorListener errorListener) {
//        query = query.replaceAll(" ", "%20");
//        String url = "http://noqapp.in/noq/prod/purchase/getsupplier/" + query;
//        Log.i("sdfesd",url);
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
//                listener, errorListener);
//        ApiCall.getInstance(ctx).addToRequestQueue(stringRequest);
//    }
//    public static void getproduct(Context ctx, String query, Response.Listener<String>
//            listener, Response.ErrorListener errorListener) {
//        query = query.replaceAll(" ", "%20");
//        String url = "http://noqapp.in/noq/prod/purchase/getproduct/" + query;
//        Log.i("sdfesd",url);
//        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
//                listener, errorListener);
//        ApiCall.getInstance(ctx).addToRequestQueue(stringRequest);
//    }
    public static void make(Context ctx, String query, Response.Listener<String>
            listener, Response.ErrorListener errorListener) {
        query = query.replaceAll(" ", "%20");
        String url = "http://noqapp.in/noq/prod/api/fetchrecordcustomer_formobile/" + query;
        Log.i("sdfesd",url);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                listener, errorListener);
        ApiCall.getInstance(ctx).addToRequestQueue(stringRequest);
    }
    public static void checkstock(Context ctx, String query, Response.Listener<String>
            listener, Response.ErrorListener errorListener) {
        query = query.replaceAll(" ", "%20");
        String url = "http://noqapp.in/noq/prod/api/getstockid/" + query;
        Log.i("sdfesd",url);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                listener, errorListener);
        ApiCall.getInstance(ctx).addToRequestQueue(stringRequest);
    }
}

package com.doers.noqadmin.models;

public class orderitemsModel {
    public String itm_name, itm_qty, itm_rate, itm_tot;

    public String getItm_name() {
        return itm_name;
    }

    public void setItm_name(String itm_name) {
        this.itm_name = itm_name;
    }

    public String getItm_qty() {
        return itm_qty;
    }

    public void setItm_qty(String itm_qty) {
        this.itm_qty = itm_qty;
    }

    public String getItm_rate() {
        return itm_rate;
    }

    public void setItm_rate(String itm_rate) {
        this.itm_rate = itm_rate;
    }

    public String getItm_tot() {
        return itm_tot;
    }

    public void setItm_tot(String itm_tot) {
        this.itm_tot = itm_tot;
    }

    public orderitemsModel(String itm_name, String itm_qty, String itm_rate, String itm_tot) {
        this.itm_name=itm_name;
        this.itm_qty=itm_qty;
        this.itm_rate=itm_rate;
        this.itm_tot=itm_tot;
    }


}
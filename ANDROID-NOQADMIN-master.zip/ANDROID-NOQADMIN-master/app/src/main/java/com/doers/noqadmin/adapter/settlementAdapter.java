package com.doers.noqadmin.adapter;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.doers.noqadmin.AdminMain;
import com.doers.noqadmin.ExpenseActivity;
import com.doers.noqadmin.R;
import com.doers.noqadmin.TopUp;
import com.doers.noqadmin.models.UserModel;
import com.doers.noqadmin.models.expenseModel;
import com.doers.noqadmin.models.userunsettledModel;
import com.doers.noqadmin.utils.DBHelper;
import com.doers.noqadmin.utils.DialogManager;
import com.fxn.pix.Options;
import com.fxn.pix.Pix;
import com.fxn.utility.ImageQuality;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialog;
import com.shashank.sony.fancydialoglib.FancyAlertDialogListener;
import com.shashank.sony.fancydialoglib.Icon;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.shts.android.library.TriangleLabelView;

public class settlementAdapter  extends RecyclerView.Adapter<settlementAdapter.ViewHolder> {

    private Activity context;
    private List<userunsettledModel> personUtils;
    DBHelper mydb;
    private Date selectedDate;
    private TextView tvTitle;
    private Button btnDate;
    private EditText etDescription;
    private EditText etTotal;
    private Button BTN_SAVEEXPENSE,BTN_CANCELEXPENSE;
    String STR_COLAMT,STR_CID,STR_SID,STR_NOTES,STR_CDATE;

    public settlementAdapter(Activity context, List personUtils) {
        this.context = context;
        this.personUtils = personUtils;
    }

    @Override
    public settlementAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.userunsetlist_item, parent, false);
        settlementAdapter.ViewHolder viewHolder = new settlementAdapter.ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(settlementAdapter.ViewHolder holder, int position) {
        holder.itemView.setTag(personUtils.get(position));
        userunsettledModel pu = personUtils.get(position);
            holder.NAME.setText(pu.getUser_name());
            holder.TODAY.setText("₹ "+pu.getToday_unsettled());
            holder.TOTAL.setText("₹ "+pu.getTotal_unsettled());
        holder.COLLECT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(view.getContext(), pu.getUser_id()+" is "+ pu.getUser_name(), Toast.LENGTH_SHORT).show();
                popupexpensedialog(pu);
                Toast.makeText(context, pu.getUser_id(), Toast.LENGTH_SHORT).show();
            }
        });


    }

    @Override
    public int getItemCount() {
        return personUtils.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView NAME,TODAY,TOTAL;
        ImageView COLLECT;


        public ViewHolder(View itemView) {
            super(itemView);
            NAME = itemView.findViewById(R.id.unst_username);
            TODAY = itemView.findViewById(R.id.unst_today);
            TOTAL = itemView.findViewById(R.id.unst_total);
            COLLECT = itemView.findViewById(R.id.btn_collect);




        }
    }

    public void popupexpensedialog(userunsettledModel cpu){
        LayoutInflater li = LayoutInflater.from(context);
        View promptsView = li.inflate(R.layout.dialog_addsettlement, null);
        selectedDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String dateTime = dateFormat.format(selectedDate);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        // set prompts.xml to alertdialog builder
        alertDialogBuilder.setView(promptsView);
        tvTitle = (TextView)promptsView.findViewById(R.id.tv_title);
        btnDate = (Button)promptsView.findViewById(R.id.btn_date);
        etDescription = (EditText)promptsView.findViewById(R.id.et_description);
        etTotal = (EditText)promptsView.findViewById(R.id.et_total);
        BTN_SAVEEXPENSE = (Button) promptsView.findViewById(R.id.btn_save);
        BTN_CANCELEXPENSE = (Button)promptsView.findViewById(R.id.btn_cancel);
        mydb=new DBHelper(context);
        UserModel userModel = new UserModel();
        userModel = mydb.getAllUsers();
        if(userModel.getUemail()==null){
        }else{
            STR_CID=String.valueOf(userModel.getUid());
        }
        etTotal.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(editable.length()>0){
                    STR_COLAMT = editable.toString();
                    Double colamt = Double.parseDouble(STR_COLAMT);
                    Double colmax = Double.parseDouble(cpu.getTotal_unsettled());
                    if(colamt==0){
                        etTotal.removeTextChangedListener(this);
                        STR_COLAMT = "1";
                        etTotal.setText("1");
                        colamt=Double.parseDouble(STR_COLAMT);
                        etTotal.addTextChangedListener(this);
                    }
                    if(colamt>colmax){
                        etTotal.removeTextChangedListener(this);
                        colamt=colmax;
                        STR_COLAMT = String.valueOf(colamt);
                        etTotal.setText(STR_COLAMT);
                        etTotal.addTextChangedListener(this);

                    }

                }else{

                }
            }
        });
tvTitle.setText("Collect Amount from \n"+cpu.getUser_name());

        btnDate.setText(dateTime);
        btnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                showDateDialog();

            }
        });
        // set dialog message
        alertDialogBuilder
                .setCancelable(true);
        // create alert dialog
        final AlertDialog alertDialog = alertDialogBuilder.create();
        BTN_SAVEEXPENSE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
                try{
                    if(!TextUtils.isEmpty(etDescription.getText())){
                        STR_NOTES=etDescription.getText().toString();
                    }else{
                        STR_NOTES="_";
                    }

                }catch (Exception d){
                    STR_NOTES="_";
                }
                STR_SID = cpu.getUser_id();

                STR_CDATE=btnDate.getText().toString();


                collect();
            }
        });
        BTN_CANCELEXPENSE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });
        // show it
        alertDialog.show();
    }
    private void showDateDialog() {
        final Calendar calendar = Calendar.getInstance();
        calendar.setTime(selectedDate);
        DialogManager.getInstance().showDatePickerDialog(context, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                calendar.set(year, month, day);
                selectedDate = calendar.getTime();
                updateDate();
            }
        }, calendar);
    }
    private void updateDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String dateTime = dateFormat.format(selectedDate);
        System.out.println("Current Date Time : " + dateTime);
        btnDate.setText(dateTime);
    }
    public void collect(){
        final ProgressDialog dlg = new ProgressDialog(context);
        dlg.setMessage("Settlement Processing...");
        dlg.setCancelable(false);
        dlg.show();



        String url = "http://noqapp.in/noq/prod/api/collect_settlement/";

        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i
                        Log.i("VALUE",response.toString());
                        try {
                            JSONObject jobj = new JSONObject(response);
                            String STATUS = jobj.getString("status");
                            String msg = jobj.getString("msg");
                            try{ dlg.dismiss();}
                            catch (Exception dsf){

                            }
                            new FancyAlertDialog.Builder(context)
                                    .setTitle("NOQ Settlement")
                                    .setBackgroundColor(Color.parseColor("#0D0135"))  //Don't pass R.color.colorvalue
                                    .setMessage(msg)
                                    .setPositiveBtnBackground(Color.parseColor("#FF4081"))  //Don't pass R.color.colorvalue
                                    .setPositiveBtnText("Ok")
                                    .setNegativeBtnText("Cancel")
                                    .setIcon(R.drawable.ic_done, Icon.Visible)
                                    .setAnimation(Animation.POP)
                                    .isCancellable(false)
                                    .OnNegativeClicked(new FancyAlertDialogListener() {
                                        @Override
                                        public void OnClick() {
//
                                        }
                                    }).OnPositiveClicked(new FancyAlertDialogListener() {
                                @Override
                                public void OnClick() {
                                    Intent setIntent = new Intent(context, AdminMain.class);
                                    setIntent.addCategory(Intent.CATEGORY_HOME);
                                    setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    context.startActivity(setIntent);
                                    context.finish();
                                }
                            })
                                    .build();

                        } catch (JSONException e) {
                            try{ dlg.dismiss();}
                            catch (Exception dsf){

                            }
                            e.printStackTrace();
                        }



                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        try{ dlg.dismiss();}
                        catch (Exception dsf){

                        }
                        Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map getParams()
            {
                Map params = new HashMap();
                params.put("cid",STR_CID);
                params.put("sid", STR_SID);
                params.put("amount", STR_COLAMT);
                params.put("notes", STR_NOTES);
                params.put("cdate", STR_CDATE);

                return params;
            }

        };
        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }

}
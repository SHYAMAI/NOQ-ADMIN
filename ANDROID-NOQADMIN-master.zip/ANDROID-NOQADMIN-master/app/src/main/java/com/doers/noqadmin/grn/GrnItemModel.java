package com.doers.noqadmin.grn;

public class GrnItemModel {
    String prd_name;

    String prd_id,prd_barcode;

    String prd_qty;
    String prd_price;

    public String getPrd_id() {
        return prd_id;
    }

    public void setPrd_id(String prd_id) {
        this.prd_id = prd_id;
    }

    public String getPrd_barcode() {
        return prd_barcode;
    }

    public void setPrd_barcode(String prd_barcode) {
        this.prd_barcode = prd_barcode;
    }

    public GrnItemModel(String prd_id, String prd_barcode, String prd_name, String prd_qty, String prd_price) {
        this.prd_name=prd_name;
        this.prd_qty=prd_qty;
        this.prd_price=prd_price;
        this.prd_id=prd_id;
        this.prd_barcode=prd_barcode;

    }
    public String getPrd_name() {
        return prd_name;
    }

    public void setPrd_name(String prd_name) {
        this.prd_name = prd_name;
    }

    public String getPrd_qty() {
        return prd_qty;
    }

    public void setPrd_qty(String prd_qty) {
        this.prd_qty = prd_qty;
    }

    public String getPrd_price() {
        return prd_price;
    }

    public void setPrd_price(String prd_price) {
        this.prd_price = prd_price;
    }


}

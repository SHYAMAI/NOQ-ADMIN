package com.doers.noqadmin.utils;

import android.annotation.SuppressLint;

import com.journeyapps.barcodescanner.CaptureActivity;

@SuppressLint("Registered")
public class CaptureActivityAnyOrientation extends CaptureActivity {

}
package com.doers.noqadmin;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.doers.noqadmin.adapter.AttAdapter;
import com.doers.noqadmin.adapter.expenseAdapter;
import com.doers.noqadmin.models.UserModel;
import com.doers.noqadmin.models.expenseCategorymodel;
import com.doers.noqadmin.models.expenseModel;
import com.doers.noqadmin.utils.DBHelper;
import com.doers.noqadmin.utils.DialogManager;
import com.doers.noqadmin.utils.MultipartRequest;
import com.doers.noqadmin.utils.VolleySingleton;
import com.fxn.pix.Options;
import com.fxn.pix.Pix;
import com.fxn.utility.ImageQuality;
import com.fxn.utility.PermUtil;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class ExpenseActivity extends AppCompatActivity {
private TextView TXT_TOTALEXPENSES;
private FloatingActionButton FAB_EXPENCEADD;

    DBHelper mydb;
    RecyclerView recyclerView;
    RecyclerView.Adapter<expenseAdapter.ViewHolder> mAdapter;
    RecyclerView.LayoutManager layoutManager;
    List<expenseModel> personUtilsList;
    ArrayList<expenseCategorymodel> categories,Spentuser;
    private TextView tvTitle;
    private Button btnDate;
    private Spinner spCategory,spspentuser;
    private EditText etDescription;
    private EditText etTotal;
    private Date selectedDate;
    private Button BTN_SAVEEXPENSE,BTN_CANCELEXPENSE;
   String ex_category_id,ex_category_name,ex_notes,ex_expense,ex_create_user,ex_create_username,ex_spent_user,ex_mode,ex_spent_date,ex_spent_user_name;

    GridView attgridview;
    AttAdapter attAdapter;
    Options options;
    ArrayList<String> returnValue = new ArrayList<>();
    String attachlist;
    ArrayList<byte[]> newarr = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Expense Entry");
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        mydb=new DBHelper(ExpenseActivity.this);
        categories = new ArrayList<>();
        Spentuser = new ArrayList<>();
        getallexpense();
        loadSpinnerData();
        loadSpentuserData();
        TXT_TOTALEXPENSES =findViewById(R.id.txt_totalexp);
        FAB_EXPENCEADD =findViewById(R.id.fab_expenseadd);
        TXT_TOTALEXPENSES.setText("\u20B9"+mydb.getTotalExpense());
        FAB_EXPENCEADD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popupexpensedialog();
            }
        });
        recyclerView = (RecyclerView) findViewById(R.id.expenses_list);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        personUtilsList = new ArrayList<>();
        UserModel userModel = new UserModel();
        userModel = mydb.getAllUsers();
        if(userModel.getUemail()==null){
        }else{
            ex_create_username=String.valueOf(userModel.getUname());
            ex_create_user=String.valueOf(userModel.getUid());
        }
        ArrayList<expenseModel> expmodel =new ArrayList<>();
       expmodel = mydb.getAllExpense();
for(int i=0;i<expmodel.size();i++){
    personUtilsList.add(new expenseModel(expmodel.get(i).getExp_id(),expmodel.get(i).getExp_category(),expmodel.get(i).getExp_categoryname(),
            expmodel.get(i).getExp_desc(),expmodel.get(i).getExp_amount(),expmodel.get(i).getExp_mode(), expmodel.get(i).getExp_loguser(),expmodel.get(i).getExp_logusername(),
            expmodel.get(i).getExp_spentuser(),expmodel.get(i).getExp_spentusername(),expmodel.get(i).getExpcdate(),expmodel.get(i).getExpsdate(),expmodel.get(i).getExpstatus()));
}
        mAdapter = new expenseAdapter(this, personUtilsList);
        recyclerView.setAdapter(mAdapter);
    }

    public void popupexpensedialog(){
        LayoutInflater li = LayoutInflater.from(this);
        View promptsView = li.inflate(R.layout.dialog_addexpense, null);
        selectedDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String dateTime = dateFormat.format(selectedDate);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                this);
        // set prompts.xml to alertdialog builder
        alertDialogBuilder.setView(promptsView);
        tvTitle = (TextView)promptsView.findViewById(R.id.tv_title);
        btnDate = (Button)promptsView.findViewById(R.id.btn_date);
        spCategory = (Spinner)promptsView.findViewById(R.id.sp_categories);
        spspentuser = (Spinner)promptsView.findViewById(R.id.sp_spent_user);
        etDescription = (EditText)promptsView.findViewById(R.id.et_description);
        etTotal = (EditText)promptsView.findViewById(R.id.et_total);
        BTN_SAVEEXPENSE = (Button) promptsView.findViewById(R.id.btn_save);
        BTN_CANCELEXPENSE = (Button)promptsView.findViewById(R.id.btn_cancel);
        Button BTN_ADDATTACHMENT = (Button)promptsView.findViewById(R.id.exp_addAtt);

        attgridview=(GridView)promptsView.findViewById(R.id.attachments_list);

        attgridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Toast.makeText(ExpenseActivity.this, "You Clicked at " + position, Toast.LENGTH_SHORT).show();

            }
        });

        attgridview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.i("pos", String.valueOf(i));
//                attAdapter.removeItem(i);
                returnValue.remove(i);
                attAdapter = new AttAdapter(ExpenseActivity.this,returnValue);
                attgridview.setAdapter(attAdapter);
                return false;
            }
        });


        options = Options.init()
                .setRequestCode(100)
                .setCount(3)
                .setFrontfacing(false)
                .setImageQuality(ImageQuality.LOW)
                .setPreSelectedUrls(returnValue)
                .setScreenOrientation(Options.SCREEN_ORIENTATION_PORTRAIT)
                .setPath("/noq/cache");

        BTN_ADDATTACHMENT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                options.setPreSelectedUrls(returnValue);
                Pix.start(ExpenseActivity.this, options);
            }
        });


        btnDate.setText(dateTime);
        loadData();
        btnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                showDateDialog();

            }
        });
        // set dialog message
        alertDialogBuilder
                .setCancelable(true);
        // create alert dialog
        final AlertDialog alertDialog = alertDialogBuilder.create();
        BTN_SAVEEXPENSE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Gson gsonBuilder = new GsonBuilder().create();




              //  attachlist = gsonBuilder.toJson(newarr);
                ex_notes=etDescription.getText().toString();
                ex_expense=etTotal.getText().toString();
                ex_mode="SPENT";
                ex_spent_date=btnDate.getText().toString();
                saveexpense();
                alertDialog.dismiss();
            }
        });
        BTN_CANCELEXPENSE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });
        // show it
        alertDialog.show();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e("val", "requestCode ->  " + requestCode+"  resultCode "+resultCode);
        switch (requestCode) {
            case (100): {
                if (resultCode == Activity.RESULT_OK) {
                    returnValue = data.getStringArrayListExtra(Pix.IMAGE_RESULTS);
                    attAdapter = new AttAdapter(ExpenseActivity.this,returnValue);
                    attgridview.setAdapter(attAdapter);
                }
            }
            break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case PermUtil.REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Pix.start(ExpenseActivity.this, options);
                } else {
                    Toast.makeText(ExpenseActivity.this, "Approve permissions to open NOQ ImagePicker", Toast.LENGTH_LONG).show();
                }
                return;
            }
        }
    }

public void loadData(){

    if (categories.size() > 0) {
        ArrayAdapter<expenseCategorymodel> arrayAdapter = new ArrayAdapter<>(ExpenseActivity.this, android.R.layout.simple_spinner_dropdown_item, categories);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCategory.setAdapter(arrayAdapter);
        spCategory.setSelection(0);
    }
    if (Spentuser.size() > 0) {
        ArrayAdapter<expenseCategorymodel> array1Adapter = new ArrayAdapter<>(ExpenseActivity.this, android.R.layout.simple_spinner_dropdown_item, Spentuser);
        array1Adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spspentuser.setAdapter(array1Adapter);
                for (int j =0;j<Spentuser.size();j++){
                    String sd = Spentuser.get(j).getStrCode();
            if(Double.parseDouble(sd)==Double.parseDouble(ex_create_user)){
                spspentuser.setSelection(j);
            }
        }


       // spspentuser.setSelection(5);
    }

//
//    spCategory.setAdapter(new ArrayAdapter<String>(ExpenseActivity.this, android.R.layout.simple_spinner_dropdown_item, CategoryName));
//    spCategory.setSelection(0);
//    spspentuser.setAdapter(new ArrayAdapter<String>(ExpenseActivity.this, android.R.layout.simple_spinner_dropdown_item, Spentuser));
//    spspentuser.setSelection(5);
    spCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            String id = categories.get(i).getStrCode();
            String desc = categories.get(i).getStrDesc();
            ex_category_id=categories.get(i).getStrCode();
            ex_category_name=categories.get(i).getStrDesc();
        Log.e("Log", "id " + id + " desc " + desc);
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {
            ex_category_id="1";
            ex_category_name="TRAVEL EXPENSE";
        }
    });
    spspentuser.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            String id = Spentuser.get(i).getStrCode();
            String desc = Spentuser.get(i).getStrDesc();
            ex_spent_user=Spentuser.get(i).getStrCode();
            ex_spent_user_name=Spentuser.get(i).getStrDesc();
            Log.e("Log", "id " + id + " desc " + desc);
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {
            ex_spent_user=ex_create_user;
            ex_spent_user_name=ex_create_username;
        }
    });
}

    private void saveexpense() {
        final ProgressDialog dlg = new ProgressDialog(this);
        dlg.setMessage("Submitting Expense...");
        dlg.setCancelable(false);
        dlg.show();


        // loading or check internet connection or something...
        // ... then
        String url = "http://noqapp.in/noq/prod/api/save_expense/";
        MultipartRequest multipartRequest = new MultipartRequest(Request.Method.POST, url, new Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse resultResponse) {
                dlg.dismiss();
                String response = new String(resultResponse.data);
                Log.i("VALUEe", response.toString());
                try {
                    JSONObject jobj = new JSONObject(response.toString());
                    if (jobj.getBoolean("status")) {
                        JSONObject jne = new JSONObject(jobj.getString("data"));
                        Integer exp_id;
                        String exp_category, exp_category_name, exp_desc, exp_amount, exp_loguser, exp_spentuser, expcdate, expsdate, exp_mode, exp_status, exp_loguser_name, exp_spentuser_name;
                        exp_id = jne.getInt("id");
                        exp_category = jne.getString("category_id");
                        exp_category_name = jne.getString("category_name");
                        exp_desc = jne.getString("notes");
                        exp_amount = jne.getString("expense");
                        exp_mode = jne.getString("mode");
                        exp_loguser = jne.getString("create_user");
                        exp_loguser_name = jne.getString("create_user_name");
                        exp_spentuser = jne.getString("spent_user");
                        exp_spentuser_name = jne.getString("spent_user_name");
                        expcdate = jne.getString("create_date");
                        expsdate = jne.getString("spent_date");
                        exp_status = jne.getString("status");

                        long iv = mydb.addExpense(exp_id, exp_category, exp_category_name, exp_desc, exp_amount, exp_mode, exp_loguser, exp_loguser_name, exp_spentuser, exp_spentuser_name, expcdate, expsdate, exp_status);
                        Log.i("rest", String.valueOf(iv));
                        addexpense("");

                    } else {
                        Toast.makeText(ExpenseActivity.this, "Sorry ! Try Again", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    Toast.makeText(ExpenseActivity.this, "Sorry ! Try Again", Toast.LENGTH_SHORT).show();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dlg.dismiss();
                NetworkResponse networkResponse = error.networkResponse;
                String errorMessage = "Unknown error";
                if (networkResponse == null) {
                    if (error.getClass().equals(TimeoutError.class)) {
                        errorMessage = "Request timeout";
                    } else if (error.getClass().equals(NoConnectionError.class)) {
                        errorMessage = "Failed to connect server";
                    }
                } else {
                    String result = new String(networkResponse.data);
                    try {
                        JSONObject response = new JSONObject(result);
                        String status = response.getString("status");
                        String message = response.getString("message");

                        Log.e("Error Status", status);
                        Log.e("Error Message", message);

                        if (networkResponse.statusCode == 404) {
                            errorMessage = "Resource not found";
                        } else if (networkResponse.statusCode == 401) {
                            errorMessage = message+" Please login again";
                        } else if (networkResponse.statusCode == 400) {
                            errorMessage = message+ " Check your inputs";
                        } else if (networkResponse.statusCode == 500) {
                            errorMessage = message+" Something is getting wrong";
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                Log.i("Error", errorMessage);
                error.printStackTrace();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                    params.put("category_id",ex_category_id);
                    params.put("notes", ex_notes);
                    params.put("expense", ex_expense);
                    params.put("create_user", ex_create_user);
                    params.put("spent_user", ex_spent_user);
                    params.put("mode", ex_mode);
                    params.put("spent_date", ex_spent_date);
                    Log.i("sfdsf",params.toString());
                    return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                // file name could found file base or direct access from real path
                // for now just get bitmap data from ImageView
                int in=1;
                for (String ret:returnValue) {
                    params.put("image"+in, new MultipartRequest.DataPart("image"+in+".jpeg", encodeImage(ret), "image/jpeg"));
               in++;
                }
                Log.i("params",params.toString());
                return params;
            }
        };

        VolleySingleton.getInstance(getBaseContext()).addToRequestQueue(multipartRequest);
    }


//
//    public void saveexpense() {
//        String url = "http://noqapp.in/noq/prod/api/save_expense/";
//        //creating a string request to send request to the url
//        MultipartRequest multipartRequest = new MultipartRequest(Request.Method.POST, url, new Response.Listener<NetworkResponse>() {
//
//            @Override
//            public void onResponse(NetworkResponse response) {
//
//                //hiding the progressbar after completionLog.i
//
//
//            }
//
//        });
//    }


//    {
//        Map<String, String> params = new HashMap<String, String>();
//        params.put("category_id",ex_category_id);
//        params.put("notes", ex_notes);
//        params.put("expense", ex_expense);
//        params.put("create_user", ex_create_user);
//        params.put("spent_user", ex_spent_user);
//        params.put("mode", ex_mode);
//        params.put("spent_date", ex_spent_date);
//        params.put("attachlist", attachlist);
//        Log.i("sfdsf",params.toString());
//        return params;
//    }
    private byte[] encodeImage(String path)
    {
        File imagefile = new File(path);
        FileInputStream fis = null;
        try{
            fis = new FileInputStream(imagefile);
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }
        Bitmap bm = BitmapFactory.decodeStream(fis);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG,80,baos);
        byte[] b = baos.toByteArray();
//        String encImage = Base64.encodeToString(b, Base64.DEFAULT);
        //Base64.de
        return b;

    }
    public void loadSpinnerData(){
        String url = "http://noqapp.in/noq/prod/api/get_expensecategory/";

        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i

                        Log.i("VALUE",response.toString());
                        categories = new ArrayList<>();
                        try {
                            JSONArray jarray = new JSONArray(response);
                            for(int i=0;i<jarray.length();i++){
                                JSONObject jobj = jarray.getJSONObject(i);
                                categories.add(new expenseCategorymodel(jobj.getString("id"),jobj.getString("category_name")));
                            }

//                            spCategory.setAdapter(new ArrayAdapter<String>(ExpenseActivity.this, android.R.layout.simple_spinner_dropdown_item, CategoryName));
//                            spCategory.setSelection(0);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        try{ }
                        catch (Exception dsf){

                        }
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map getParams()
            {
                Map params = new HashMap();

                return params;
            }

        };
        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }
    public void loadSpentuserData(){

        String url = "http://noqapp.in/noq/prod/api/get_expenseuser/";

        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i
                        Log.i("VALUE",response.toString());
                        Spentuser=new ArrayList<>();

                        try {
                            JSONArray jarray = new JSONArray(response);
                            for(int i=0;i<jarray.length();i++){
                                JSONObject jobj = jarray.getJSONObject(i);
                                Spentuser.add(new expenseCategorymodel(jobj.getString("id"),jobj.getString("name")));

                            }

//                            spspentuser.setAdapter(new ArrayAdapter<String>(ExpenseActivity.this, android.R.layout.simple_spinner_dropdown_item, Spentuser));
//                            spspentuser.setSelection(0);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        try{}
                        catch (Exception dsf){

                        }
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map getParams()
            {
                Map params = new HashMap();

                return params;
            }

        };
        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }

    public void getallexpense(){
        String url = "http://noqapp.in/noq/prod/api/get_expenselist/";
        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i
                        Log.i("VALUEe",response.toString());
                        try {
                            JSONArray jarr = new JSONArray(response);
                            mydb.deleteAllExpenses();
                            for(int i=0;i<jarr.length();i++){



                                JSONObject jne =jarr.getJSONObject(i);
                                Integer exp_id;
                                String exp_category,exp_category_name,exp_desc,exp_amount,exp_loguser,exp_spentuser,expcdate,expsdate,exp_mode,exp_status,exp_loguser_name,exp_spentuser_name;


                                exp_id=jne.getInt("id");
                                exp_category=jne.getString("category_id");
                                exp_category_name=jne.getString("category_name");
                                exp_desc=jne.getString("notes");
                                exp_amount=jne.getString("expense");
                                exp_mode=jne.getString("mode");
                                exp_loguser=jne.getString("create_user");
                                exp_loguser_name=jne.getString("create_user_name");
                                exp_spentuser=jne.getString("spent_user");
                                exp_spentuser_name=jne.getString("spent_user_name");
                                expcdate=jne.getString("create_date");
                                expsdate=jne.getString("spent_date");
                                exp_status=jne.getString("status");


                                long iv=  mydb.addExpense(exp_id,exp_category,exp_category_name,exp_desc,exp_amount,exp_mode,exp_loguser,exp_loguser_name,exp_spentuser,exp_spentuser_name,expcdate,expsdate,exp_status);
                                Log.i("rest",String.valueOf(iv));

                            }
                            addexpense("");

                        } catch (JSONException e) {
                            Toast.makeText(ExpenseActivity.this, "Sorry ! Try Again", Toast.LENGTH_SHORT).show();

                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        try{ }
                        catch (Exception dsf){

                        }
                        Toast.makeText(ExpenseActivity.this, "Sorry ! Try Again", Toast.LENGTH_SHORT).show();
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map getParams()
            {
                Map<String, String> params = new HashMap<String, String>();

                return params;
            }

        };
        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }
    private void showDateDialog() {
        final Calendar calendar = Calendar.getInstance();
        calendar.setTime(selectedDate);
        DialogManager.getInstance().showDatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                calendar.set(year, month, day);
                selectedDate = calendar.getTime();
                updateDate();
            }
        }, calendar);
    }
    private void updateDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String dateTime = dateFormat.format(selectedDate);
        System.out.println("Current Date Time : " + dateTime);
        btnDate.setText(dateTime);
    }
    public void addexpense(String Amount){
        personUtilsList = new ArrayList<>();
        //Adding Data into ArrayList
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        personUtilsList = new ArrayList<>();
        ArrayList<expenseModel> expmodel =new ArrayList<>();
        expmodel = mydb.getAllExpense();
        for(int i=0;i<expmodel.size();i++){
            personUtilsList.add(new expenseModel(expmodel.get(i).getExp_id(),expmodel.get(i).getExp_category(),expmodel.get(i).getExp_categoryname(),
                    expmodel.get(i).getExp_desc(),expmodel.get(i).getExp_amount(),expmodel.get(i).getExp_mode(), expmodel.get(i).getExp_loguser(),expmodel.get(i).getExp_logusername(),
                    expmodel.get(i).getExp_spentuser(),expmodel.get(i).getExp_spentusername(),expmodel.get(i).getExpcdate(),expmodel.get(i).getExpsdate(),expmodel.get(i).getExpstatus()));
        }
        mAdapter = new expenseAdapter(this, personUtilsList);

        recyclerView.setAdapter(mAdapter);
        mAdapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                TXT_TOTALEXPENSES.setText("\u20B9"+mydb.getTotalExpense());
            }
        });
        mAdapter.notifyDataSetChanged();
    }
}

package com.doers.noqadmin.stockupdate;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.doers.noqadmin.R;
import com.doers.noqadmin.TopUp;
import com.doers.noqadmin.models.UserModel;
import com.doers.noqadmin.utils.ApiCall;
import com.doers.noqadmin.utils.AutoSuggestAdapter;
import com.doers.noqadmin.utils.CaptureActivityAnyOrientation;
import com.doers.noqadmin.utils.CustomerModel;
import com.doers.noqadmin.utils.DBHelper;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.otaliastudios.autocomplete.Autocomplete;
import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialog;
import com.shashank.sony.fancydialoglib.FancyAlertDialogListener;
import com.shashank.sony.fancydialoglib.Icon;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class stockUpdate extends AppCompatActivity {

    private static final int TRIGGER_AUTO_COMPLETE = 100;
    private static final long AUTO_COMPLETE_DELAY = 300;
    private Handler handler;
    private StockAutoSuggestAdapter autoSuggestAdapter;
    AppCompatAutoCompleteTextView autoCompleteTextView;
    LinearLayout showcontent;
    String login_user;
    DBHelper mydb;
    Button BTN_UPDATE;
    ImageView BTN_SCAN,BTN_REDUCE,BTN_ADD;
    TableRow PRD_DETAILS;
    TextView PRD_NAME,PRD_PRICE,PRD_CSTOCK,PRD_ASTOCK,STK_DESC;
    String STR_PRDID,STR_PRDNAME,STR_CSTOCK,STR_ASTOCK,STR_DESC,STR_AMODE,STR_BARCODE,STR_PRICE,STR_ADJQTY;
    private String scanContent,scanFormat;
private Boolean isscanned=false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stockupdate);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Stock Adjustment");
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        showcontent = findViewById(R.id.showcontent);
        autoCompleteTextView = findViewById(R.id.topbar);
        BTN_UPDATE = findViewById(R.id.btn_update);
        BTN_SCAN = findViewById(R.id.btn_scan);
        PRD_DETAILS = findViewById(R.id.prddetails);
        PRD_NAME = findViewById(R.id.stk_prdname);
        PRD_PRICE = findViewById(R.id.stk_prdprice);
        PRD_CSTOCK = findViewById(R.id.stk_current);
        PRD_ASTOCK = findViewById(R.id.stk_adjusted);
        BTN_REDUCE = findViewById(R.id.btn_reduce);
        BTN_ADD = findViewById(R.id.btn_add);
        STK_DESC = findViewById(R.id.stk_desc);

        PRD_DETAILS.setVisibility(View.INVISIBLE);
        showcontent.setVisibility(View.INVISIBLE);


        STR_DESC = "_";
        mydb = new DBHelper(stockUpdate.this);
        BTN_UPDATE.setEnabled(false);

        UserModel userModel = new UserModel();
        userModel = mydb.getAllUsers();
        if (userModel.getUemail() == null) {
            login_user = "123";
        } else {
            login_user = String.valueOf(userModel.getUid());

        }


        List<stockmodel> stringList = new ArrayList<>();

        autoSuggestAdapter = new StockAutoSuggestAdapter(stockUpdate.this, android.R.layout.simple_dropdown_item_1line, stringList);
        autoCompleteTextView.setThreshold(2);
        autoCompleteTextView.setAdapter(autoSuggestAdapter);
        autoCompleteTextView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view,
                                            int position, long id) {
                        stockmodel cim = autoSuggestAdapter.getItem(position);
                        showcontent.setVisibility(View.VISIBLE);
                        PRD_DETAILS.setVisibility(View.VISIBLE);

                        STR_PRDNAME = cim.getName();
                        STR_PRDID =cim.getId();
                        STR_BARCODE = cim.getBarcode();
                        STR_PRICE = cim.getPrice();
                        PRD_NAME.setText(STR_PRDNAME + " (" + STR_BARCODE + ")");
                        PRD_PRICE.setText("\u20B9" + STR_PRICE);


                        getstock(STR_PRDID);

                    }
                });
        PRD_ASTOCK.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int
                    count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {


            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length()>0){
                    STR_ASTOCK = s.toString();
                    Double astock = Double.parseDouble(STR_ASTOCK);
                    Double cstock = Double.parseDouble(STR_CSTOCK);
                    if(astock==0){
                        PRD_ASTOCK.removeTextChangedListener(this);
                        STR_ASTOCK = "1";
                        PRD_ASTOCK.setText("1");
                        astock=Double.parseDouble(STR_ASTOCK);
                        PRD_ASTOCK.addTextChangedListener(this);
                    }
                    Double adjqty = 0.00;
                    if(astock>cstock){
                        STR_AMODE="ADJUSTMENT ADD";
                        adjqty =astock-cstock;
                        BTN_UPDATE.setEnabled(true);
                    }else if (astock<cstock){
                        BTN_UPDATE.setEnabled(true);
                        STR_AMODE="ADJUSTMENT MINUS FROM CURRENT STOCK";
                        adjqty =cstock-astock;
                    } else if(astock==cstock){
                        STR_AMODE="-";
                        adjqty =0.00;
                        BTN_UPDATE.setEnabled(false);
                    }else{
                        adjqty =0.00;
                        STR_AMODE="-";
                        BTN_UPDATE.setEnabled(false);
                    }
                    STR_ADJQTY=String.valueOf(adjqty);

                }else{
                    STR_ASTOCK = "1";
                    PRD_ASTOCK.setText("1");
                }

            }
        });
        autoCompleteTextView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int
                    count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                handler.sendEmptyMessageDelayed(TRIGGER_AUTO_COMPLETE,
                        AUTO_COMPLETE_DELAY);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                if (msg.what == TRIGGER_AUTO_COMPLETE) {
                    if (!TextUtils.isEmpty(autoCompleteTextView.getText())) {
                        if ((autoCompleteTextView.getText().toString().length())>3) {
                                getproduct(autoCompleteTextView.getText().toString());

                        }
                    }
                }
                return false;
            }
        });

        BTN_REDUCE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Double astock = Double.parseDouble(STR_ASTOCK);
                if(astock>1){
                    astock = astock-1;
                    STR_ASTOCK = String.valueOf(Math.round(astock));
                    PRD_ASTOCK.setText(STR_ASTOCK);
                }
            }
        });

        BTN_ADD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Double astock = Double.parseDouble(STR_ASTOCK);
                if(astock<100){
                    astock = astock+1;
                    STR_ASTOCK = String.valueOf(Math.round(astock));
                    PRD_ASTOCK.setText(STR_ASTOCK);
                }


            }
        });
        BTN_UPDATE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    if(!TextUtils.isEmpty(STK_DESC.getText())){
                        STR_DESC=STK_DESC.getText().toString();
                    }else{
                        STR_DESC="_";
                    }

                }catch (Exception d){
                    STR_DESC="_";
                }

                updatestock();
            }
        });

        BTN_SCAN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                IntentIntegrator scanIntegrator = new IntentIntegrator(stockUpdate.this);
                scanIntegrator.setPrompt("Scan");
                scanIntegrator.setBeepEnabled(true);
                //The following line if you want QR code
//                            scanIntegrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
                scanIntegrator.setCaptureActivity(CaptureActivityAnyOrientation.class);
                scanIntegrator.setOrientationLocked(false);
                scanIntegrator.setBarcodeImageEnabled(true);
                scanIntegrator.initiateScan();

            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult scanningResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (scanningResult != null) {
            if (scanningResult.getContents() != null) {
                scanContent = scanningResult.getContents();
                scanFormat = scanningResult.getFormatName();
                isscanned=true;
                autoCompleteTextView.setText(scanContent);
            }


        }else{
            Toast.makeText(this,"Nothing scanned",Toast.LENGTH_SHORT).show();
        }
    }
    public void getproduct(String query){

            String url = "http://noqapp.in/noq/prod/api/getproducts/";

        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i
                        Log.i("VALUE",response.toString());
                        try {
                            JSONArray jaarr = new JSONArray(response);
                            List<stockmodel> stringList = new ArrayList<>();
                            for(int i=0;i<jaarr.length();i++){
                                    JSONObject responseObject = jaarr.getJSONObject(i);
                                    String id, name, price, stock, adjustedstock, description,mode,barcode;

                                    id=responseObject.getString("product_id");
                                    name=responseObject.getString("name");
                                    price=responseObject.getString("price");
                                    stock="0";
                                    adjustedstock="0";
                                    description=responseObject.getString("description");
                                    mode="-";
                                    barcode=responseObject.getString("barcode");
                                    stringList.add(new stockmodel(id, name, price, stock, adjustedstock, description,mode,barcode));


                                }
                            autoSuggestAdapter = new StockAutoSuggestAdapter(stockUpdate.this, android.R.layout.simple_dropdown_item_1line, stringList);
                            autoCompleteTextView.setThreshold(2);
                            autoCompleteTextView.setAdapter(autoSuggestAdapter);
                            autoSuggestAdapter.notifyDataSetChanged();
                            if(isscanned){
                                autoCompleteTextView.setSelection(0);
                                stockmodel cim = autoSuggestAdapter.getItem(0);
                                showcontent.setVisibility(View.VISIBLE);
                                PRD_DETAILS.setVisibility(View.VISIBLE);
                                STR_PRDNAME = cim.getName();
                                STR_PRDID =cim.getId();
                                STR_BARCODE = cim.getBarcode();
                                STR_PRICE = cim.getPrice();
                                PRD_NAME.setText(STR_PRDNAME + " (" + STR_BARCODE + ")");
                                PRD_PRICE.setText("\u20B9" + STR_PRICE);
                                getstock(STR_PRDID);
                            }

                            isscanned=false;

                        } catch (JSONException e) {

                            e.printStackTrace();
                        }



                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs

                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map getParams()
            {
                Map params = new HashMap();

                return params;
            }
            @Override
            public byte[] getBody() throws AuthFailureError {
                return query.getBytes();
            }

        };
        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }


    private void getstock(String text) {
        ApiCall.checkstock(this, text, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("Resp:",response);
                //parsing logic, please change it as per your requirement
                STR_CSTOCK=response;
                STR_ASTOCK= response;
                STR_AMODE = "-";
                PRD_CSTOCK.setText("Stock:\n"+STR_CSTOCK);
                PRD_ASTOCK.setText(STR_ASTOCK);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
    }
    public void updatestock(){
        final ProgressDialog dlg = new ProgressDialog(this);
        dlg.setMessage("Stock Update Processing...");
        dlg.setCancelable(false);
        dlg.show();



        String url = "http://noqapp.in/noq/prod/products/updatestock/";

        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i
                        Log.i("VALUE",response.toString());
                        try {
                            JSONObject jobj = new JSONObject(response);
                            String STATUS = jobj.getString("status");
                            String msg = jobj.getString("msg");
                            try{ dlg.dismiss();}
                            catch (Exception dsf){

                            }

                            new FancyAlertDialog.Builder(stockUpdate.this)
                                    .setTitle("NOQ Stock Update Up")
                                    .setBackgroundColor(Color.parseColor("#0D0135"))  //Don't pass R.color.colorvalue
                                    .setMessage(msg)
                                    .setPositiveBtnBackground(Color.parseColor("#FF4081"))  //Don't pass R.color.colorvalue
                                    .setPositiveBtnText("Ok")
                                    .setNegativeBtnText("Cancel")
                                    .setIcon(R.drawable.ic_done, Icon.Visible)
                                    .setAnimation(Animation.POP)
                                    .isCancellable(false)
                                    .OnNegativeClicked(new FancyAlertDialogListener() {
                                        @Override
                                        public void OnClick() {
                                            if(Double.parseDouble(STATUS)==200){
                                                Intent setIntent = new Intent(stockUpdate.this, stockUpdate.class);
                                                setIntent.addCategory(Intent.CATEGORY_HOME);
                                                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                                startActivity(setIntent);
                                                finish();
                                            }else{
                                            }
                                        }
                                    }).OnPositiveClicked(new FancyAlertDialogListener() {
                                @Override
                                public void OnClick() {
                                    if(Double.parseDouble(STATUS)==200){
                                        Intent setIntent = new Intent(stockUpdate.this, stockUpdate.class);
                                        setIntent.addCategory(Intent.CATEGORY_HOME);
                                        setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(setIntent);
                                        finish();
                                    }else{
                                    }
                                }
                            })
                                    .build();


                        } catch (JSONException e) {
                            try{ dlg.dismiss();}
                            catch (Exception dsf){

                            }
                            e.printStackTrace();
                        }



                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        try{ dlg.dismiss();}
                        catch (Exception dsf){

                        }
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map getParams()
            {
                Map params = new HashMap();
                params.put("name",STR_PRDNAME);
                params.put("barcode", STR_BARCODE);
                params.put("price", STR_PRICE);
                params.put("product_id", STR_PRDID);
                params.put("type", STR_AMODE);
                params.put("reason", STR_DESC);
                params.put("adjqty", STR_ADJQTY);
                params.put("oldstock", STR_CSTOCK);
                params.put("manager_id", login_user);

                return params;
            }

        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));   //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }

}

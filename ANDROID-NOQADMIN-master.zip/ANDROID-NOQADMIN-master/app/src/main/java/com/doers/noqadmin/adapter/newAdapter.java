package com.doers.noqadmin.adapter;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.doers.noqadmin.R;
import com.doers.noqadmin.models.orderitemsModel;

import java.util.ArrayList;
import java.util.List;

public class newAdapter extends RecyclerView.Adapter<newAdapter.ViewHolder> {

    private Context context;
    private List<orderitemsModel> personUtils;

    public newAdapter(Context context, List personUtils) {
        this.context = context;
        this.personUtils = personUtils;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.orderitems_lay, parent, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.itemView.setTag(personUtils.get(position));

        orderitemsModel pu = personUtils.get(position);

        holder.item_name.setText(pu.getItm_name());
        holder.qty.setText(pu.getItm_qty()+" Items");
        holder.rate.setText(pu.getItm_rate());
        holder.amount.setText(pu.getItm_tot());

    }

    @Override
    public int getItemCount() {
        return personUtils.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView item_name,qty,rate,amount;


        public ViewHolder(View itemView) {
            super(itemView);

            item_name =(TextView) itemView.findViewById(R.id.itmname);
            qty =(TextView) itemView.findViewById(R.id.itmqty);
            rate =(TextView) itemView.findViewById(R.id.itmrate);
            amount =(TextView) itemView.findViewById(R.id.itmtotal);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    orderitemsModel cpu = (orderitemsModel) view.getTag();

                    Toast.makeText(view.getContext(), cpu.getItm_name()+" is "+ cpu.getItm_tot(), Toast.LENGTH_SHORT).show();

                }
            });

        }
    }

}
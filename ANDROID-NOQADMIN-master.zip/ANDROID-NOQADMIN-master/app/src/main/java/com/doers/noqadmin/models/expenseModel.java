package com.doers.noqadmin.models;

import java.io.Serializable;

public class expenseModel implements Serializable {

    public expenseModel ( Integer exp_id,String exp_category,String exp_categoryname, String exp_desc,String exp_amount,String exp_mode,String exp_loguser,
                          String exp_logusername,String exp_spentuser,String exp_spentusername,String expcdate,String expsdate,String expstatus){
        this.exp_id=exp_id;
        this.exp_category=exp_category;
        this.exp_desc=exp_desc;
        this.exp_amount=exp_amount;
        this.exp_loguser=exp_loguser;
        this.exp_spentuser=exp_spentuser;
        this.exp_mode=exp_mode;
        this.expcdate=expcdate;
        this.expsdate=expsdate;
        this.expstatus=expstatus;
        this.exp_categoryname=exp_categoryname;
        this.exp_logusername=exp_logusername;
        this.exp_spentusername=exp_spentusername;
    }

    public String getExp_categoryname() {
        return exp_categoryname;
    }

    public void setExp_categoryname(String exp_categoryname) {
        this.exp_categoryname = exp_categoryname;
    }

    public String getExp_logusername() {
        return exp_logusername;
    }

    public void setExp_logusername(String exp_logusername) {
        this.exp_logusername = exp_logusername;
    }

    public String getExp_spentusername() {
        return exp_spentusername;
    }

    public void setExp_spentusername(String exp_spentusername) {
        this.exp_spentusername = exp_spentusername;
    }

    private String exp_categoryname;
    private String exp_logusername;
    private String exp_spentusername;
    public Integer getExp_id() {
        return exp_id;
    }

    public void setExp_id(Integer exp_id) {
        this.exp_id = exp_id;
    }

    public String getExp_category() {
        return exp_category;
    }

    public void setExp_category(String exp_category) {
        this.exp_category = exp_category;
    }

    public String getExp_desc() {
        return exp_desc;
    }

    public void setExp_desc(String exp_desc) {
        this.exp_desc = exp_desc;
    }

    public String getExp_loguser() {
        return exp_loguser;
    }

    public void setExp_loguser(String exp_loguser) {
        this.exp_loguser = exp_loguser;
    }

    public String getExp_spentuser() {
        return exp_spentuser;
    }

    public void setExp_spentuser(String exp_spentuser) {
        this.exp_spentuser = exp_spentuser;
    }


    Integer exp_id; String exp_category; String exp_desc;

    public String getExp_amount() {
        return exp_amount;
    }

    public void setExp_amount(String exp_amount) {
        this.exp_amount = exp_amount;
    }

    String exp_amount;String exp_loguser;String exp_spentuser;String expdate;

    public String getExp_mode() {
        return exp_mode;
    }

    public void setExp_mode(String exp_mode) {
        this.exp_mode = exp_mode;
    }

    String exp_mode;

    public String getExpcdate() {
        return expcdate;
    }

    public void setExpcdate(String expcdate) {
        this.expcdate = expcdate;
    }

    public String getExpsdate() {
        return expsdate;
    }

    public void setExpsdate(String expsdate) {
        this.expsdate = expsdate;
    }

    public String getExpstatus() {
        return expstatus;
    }

    public void setExpstatus(String expstatus) {
        this.expstatus = expstatus;
    }

    String expcdate;String expsdate;String expstatus;




}
package com.doers.noqadmin.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.doers.noqadmin.models.UserModel;
import com.doers.noqadmin.models.expenseModel;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {


    public static final String DATABASE_NAME = "noqadmin.db";
    public static final int DATABASE_VERSION = 5;
    private static final String TABLE_USER = "users";
    private static final String TABLE_Expense = "expenses";


    public static final String USER_ID = "uid";
    public static final String USER_NAME = "uname";
    public static final String USER_MOBILE = "umobile";
    public static final String USER_EMAIL = "uemail";
    public static final String USER_STATUS = "ustatus";
    public static final String USER_TYPE = "utype";

    public static final String EXPENSE_ID = "eid";
    public static final String EXPENSE_CATEGORYID= "ecategoryid";
    public static final String EXPENSE_CATEGORYNAME= "ecategoryname";
    public static final String EXPENSE_DESCRIPTION = "edesc";
    public static final String EXPENSE_AMOUNT = "eamount";
    public static final String EXPENSE_MODE = "emode";
    public static final String EXPENSE_LUSER = "eluser";
    public static final String EXPENSE_LUSERNAME = "elusername";
    public static final String EXPENSE_SUSER = "esuser";
    public static final String EXPENSE_SUSERNAME = "esusername";
    public static final String EXPENSE_CDATE = "ecdate";
    public static final String EXPENSE_SDATE = "esdate";
    public static final String EXPENSE_STATUS = "estatus";


    private static final String CREATE_TABLE_USERS = "CREATE TABLE "
            + TABLE_USER + "(" + USER_ID
            + " INTEGER PRIMARY KEY ," + USER_NAME + " TEXT," + USER_MOBILE + " TEXT ," + USER_EMAIL + " TEXT," + USER_STATUS + " TEXT," + USER_TYPE + " TEXT);";

    private static final String CREATE_TABLE_EXPENSE = "CREATE TABLE "
            + TABLE_Expense + "(" + EXPENSE_ID
            + " INTEGER PRIMARY KEY ," + EXPENSE_CATEGORYID + " TEXT,"+ EXPENSE_CATEGORYNAME + " TEXT," + EXPENSE_DESCRIPTION + " TEXT ," + EXPENSE_AMOUNT + " TEXT," +
            EXPENSE_MODE + " TEXT," + EXPENSE_LUSER + " TEXT," + EXPENSE_LUSERNAME + " TEXT,"+ EXPENSE_SUSER + " TEXT," +EXPENSE_SUSERNAME + " TEXT," + EXPENSE_CDATE + " TEXT," +
            EXPENSE_SDATE + " TEXT ,"+ EXPENSE_STATUS+ " TEXT );";
//


    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d("table", CREATE_TABLE_USERS);
        Log.d("table", CREATE_TABLE_EXPENSE);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
       db.execSQL(CREATE_TABLE_EXPENSE);
//        db.execSQL(CREATE_TABLE_CUSTOMER);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_USER + "'");
        db.execSQL("DROP TABLE IF EXISTS '" + CREATE_TABLE_EXPENSE + "'");
        onCreate(db);
    }

    public long addUser(Integer user_id, String user_name, String user_mobile,String user_mail,String user_status,String user_type) {
        SQLiteDatabase db = this.getWritableDatabase();
        //adding user name in users table
        ContentValues values = new ContentValues();
        values.put(USER_ID, user_id);
        values.put(USER_NAME, user_name);
        values.put(USER_MOBILE, user_mobile);
        values.put(USER_EMAIL, user_mail);
        values.put(USER_STATUS, user_status);
        values.put(USER_TYPE, user_type);
        // db.insert(TABLE_USER, null, values);
        long id = db.insertWithOnConflict(TABLE_USER, null, values, SQLiteDatabase.CONFLICT_IGNORE);
return id;
    }
    public long addExpense(Integer exp_id, String exp_category, String exp_categoryname ,String exp_desc,String exp_amount,String exp_mode,String exp_loguser,String exp_logusername
            ,String exp_spentuser,String exp_spentusername,String exp_cdate,String exp_sdate,String exp_status) {
        SQLiteDatabase db = this.getWritableDatabase();
        //adding user name in users table
        ContentValues values = new ContentValues();
        values.put(EXPENSE_ID, exp_id);
        values.put(EXPENSE_CATEGORYID, exp_category);
        values.put(EXPENSE_CATEGORYNAME, exp_categoryname);
        values.put(EXPENSE_DESCRIPTION, exp_desc);
        values.put(EXPENSE_AMOUNT, exp_amount);
        values.put(EXPENSE_MODE, exp_mode);
        values.put(EXPENSE_LUSER, exp_loguser);
        values.put(EXPENSE_LUSERNAME, exp_logusername);
        values.put(EXPENSE_SUSER, exp_spentuser);
        values.put(EXPENSE_SUSERNAME, exp_spentusername);
        values.put(EXPENSE_CDATE, exp_cdate);
        values.put(EXPENSE_SDATE, exp_sdate);
        values.put(EXPENSE_STATUS, exp_status);
        // db.insert(TABLE_USER, null, values);
        long id = db.insertWithOnConflict(TABLE_Expense, null, values, SQLiteDatabase.CONFLICT_IGNORE);
        return id;
    }
    public UserModel getAllUsers() {
        UserModel userModel = new UserModel();

        String selectQuery = "SELECT  * FROM " + TABLE_USER;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                userModel.setUid(c.getInt(c.getColumnIndex(USER_ID)));
                userModel.setUname(c.getString(c.getColumnIndex(USER_NAME)));
                userModel.setUemail(c.getString(c.getColumnIndex(USER_EMAIL)));
                userModel.setUmobile(c.getString(c.getColumnIndex(USER_MOBILE)));
                userModel.setUstatus(c.getString(c.getColumnIndex(USER_STATUS)));
                userModel.setUtype(c.getString(c.getColumnIndex(USER_TYPE)));

            } while (c.moveToNext());
        }
        return userModel;
    }
    public   ArrayList<expenseModel> getAllExpense() {
        ArrayList<expenseModel> expmodel=new ArrayList<>();

        String selectQuery = "SELECT  * FROM " + TABLE_Expense;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {


                Integer id = c.getInt(c.getColumnIndex(EXPENSE_ID));
                String category=c.getString(c.getColumnIndex(EXPENSE_CATEGORYID));
                String categoryname=c.getString(c.getColumnIndex(EXPENSE_CATEGORYNAME));
                String desc =c.getString(c.getColumnIndex(EXPENSE_DESCRIPTION));
                String amount =c.getString(c.getColumnIndex(EXPENSE_AMOUNT));
                String mode =c.getString(c.getColumnIndex(EXPENSE_MODE));
                String loguser= c.getString(c.getColumnIndex(EXPENSE_LUSER));
                String logusername= c.getString(c.getColumnIndex(EXPENSE_LUSERNAME));
                String spentuser= c.getString(c.getColumnIndex(EXPENSE_SUSER));
                String spentusername= c.getString(c.getColumnIndex(EXPENSE_SUSERNAME));
                String ExpCdate=c.getString(c.getColumnIndex(EXPENSE_CDATE));
                String EXPSDATE=c.getString(c.getColumnIndex(EXPENSE_SDATE));
                String EXPSTATUS=c.getString(c.getColumnIndex(EXPENSE_STATUS));
                expmodel.add(new expenseModel(id,category,categoryname,desc,amount,mode,loguser,logusername,spentuser,spentusername,ExpCdate,EXPSDATE,EXPSTATUS));


            } while (c.moveToNext());
        }
        return expmodel;
    }

    public String getTotalExpense() {
        ArrayList<expenseModel> expmodel=new ArrayList<>();

        String selectQuery = "SELECT  sum(eamount) as Total FROM " + TABLE_Expense;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        String category="0";
        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {

                  category=c.getString(c.getColumnIndex("Total"));

            } while (c.moveToNext());
        }
        if(category==null){
            category="0.00";
        }
        return category;
    }

    public void updateUser(int id, String name, String hobby, String city) {

    }

    public void deleteUSer(int id) {

        // delete row in students table based on id
        SQLiteDatabase db = this.getWritableDatabase();

        //deleting from users table
        db.delete(TABLE_USER, USER_STATUS + " = ?",new String[]{"loggedin"});


    }
    public void deleteAllExpenses() {

        // delete row in students table based on id
        SQLiteDatabase db = this.getWritableDatabase();

        //deleting from users table
        db.delete(TABLE_Expense, EXPENSE_MODE + " = ?",new String[]{"SPENT"});
    }
    public void deleteExpense(int id) {

        // delete row in students table based on id
        SQLiteDatabase db = this.getWritableDatabase();
        //deleting from users table
        db.delete(TABLE_Expense, EXPENSE_ID + " = ?",new String[]{String.valueOf(id)});
    }

}
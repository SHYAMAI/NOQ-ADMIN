package com.doers.noqadmin.models;

import java.util.List;

public class TimeLineModel {
    public String ord_id, ord_num, ord_amount, ord_paytype, ord_paystat, ord_storeid, ord_date, ord_status, ord_customer;

    public List<orderitemsModel> getOrder_items() {
        return order_items;
    }

    public void setOrder_items(List<orderitemsModel> order_items) {
        this.order_items = order_items;
    }

    public List<orderitemsModel> order_items;
    public TimeLineModel(String ord_id, String ord_num, String ord_amount, String ord_paytype, String ord_paystat, String ord_storeid, String ord_date, String ord_status, String ord_customer, List<orderitemsModel> order_items) {

        this.ord_id=ord_id;
        this.ord_num=ord_num;
        this.ord_amount=ord_amount;
        this.ord_paytype=ord_paytype;
        this.ord_paystat=ord_paystat;
        this.ord_storeid=ord_storeid;
        this.ord_date=ord_date;
        this.ord_status=ord_status;
        this.ord_customer=ord_customer;
        this.order_items=order_items;
    }
    public String getOrd_id() {
        return ord_id;
    }

    public void setOrd_id(String ord_id) {
        this.ord_id = ord_id;
    }

    public String getOrd_num() {
        return ord_num;
    }

    public void setOrd_num(String ord_num) {
        this.ord_num = ord_num;
    }

    public String getOrd_amount() {
        return ord_amount;
    }

    public void setOrd_amount(String ord_amount) {
        this.ord_amount = ord_amount;
    }

    public String getOrd_paytype() {
        return ord_paytype;
    }

    public void setOrd_paytype(String ord_paytype) {
        this.ord_paytype = ord_paytype;
    }

    public String getOrd_paystat() {
        return ord_paystat;
    }

    public void setOrd_paystat(String ord_paystat) {
        this.ord_paystat = ord_paystat;
    }

    public String getOrd_storeid() {
        return ord_storeid;
    }

    public void setOrd_storeid(String ord_storeid) {
        this.ord_storeid = ord_storeid;
    }

    public String getOrd_date() {
        return ord_date;
    }

    public void setOrd_date(String ord_date) {
        this.ord_date = ord_date;
    }

    public String getOrd_status() {
        return ord_status;
    }

    public void setOrd_status(String ord_status) {
        this.ord_status = ord_status;
    }

    public String getOrd_customer() {
        return ord_customer;
    }

    public void setOrd_customer(String ord_customer) {
        this.ord_customer = ord_customer;
    }





}

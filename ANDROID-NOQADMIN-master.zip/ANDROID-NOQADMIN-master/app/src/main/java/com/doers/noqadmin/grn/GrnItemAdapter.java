package com.doers.noqadmin.grn;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.doers.noqadmin.R;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

public class GrnItemAdapter extends RecyclerView.Adapter<GrnItemAdapter.ViewHolder> {

    private Context context;
    private List<GrnItemModel> personUtils;

    public GrnItemAdapter(Context context, List personUtils) {
        this.context = context;
        this.personUtils = personUtils;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.grn_row_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.itemView.setTag(personUtils.get(position));
        GrnItemModel dataModel = personUtils.get(position);

        holder.txtName.setText(dataModel.getPrd_name());
        holder.txtPrice.setText(dataModel.getPrd_price());
        holder.txtQty.setText(dataModel.getPrd_qty());
        holder.txtName.setTag(position);
        holder.imgRemoveqty.setTag(position);
        holder.imgAddqty.setTag(position);
        holder.txtQty.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

             try{
                 dataModel.setPrd_qty(editable.toString());
             }catch( Exception sdf){

             }
//                notifyDataSetChanged();

            }
        });
        holder.imgAddqty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dataModel.setPrd_qty(String.valueOf(Integer.parseInt(dataModel.getPrd_qty())+1));
//                Snackbar.make(view, "Release date " +dataModel.getPrd_qty(), Snackbar.LENGTH_LONG)
//                        .setAction("No action", null).show();
                notifyDataSetChanged();
            }
        });
        holder.imgRemoveqty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(Integer.parseInt(dataModel.getPrd_qty())>1){
                    dataModel.setPrd_qty(String.valueOf(Integer.parseInt(dataModel.getPrd_qty())-1));
                }
//                Snackbar.make(view, "Release date " +dataModel.getPrd_qty(), Snackbar.LENGTH_LONG)
//                        .setAction("No action", null).show();
                notifyDataSetChanged();
            }
        });

    }

    @Override
    public int getItemCount() {
        return personUtils.size();
    }

    public List<GrnItemModel> getList(){
        return personUtils;
    }
    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView txtName;
        EditText txtQty,txtPrice;
        ImageView imgAddqty,imgRemoveqty;
        public ViewHolder(View itemView) {
            super(itemView);
            txtName = (TextView) itemView.findViewById(R.id.prdname);
            txtPrice = (EditText) itemView.findViewById(R.id.prdprice);
            txtQty = (EditText) itemView.findViewById(R.id.prdqty);
            imgAddqty = (ImageView) itemView.findViewById(R.id.addqty);
            imgRemoveqty = (ImageView) itemView.findViewById(R.id.removeqty);

        }
    }
    public void removeAt(int position) {
        personUtils.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, personUtils.size());
        notifyDataSetChanged();
    }

}
package com.doers.noqadmin.issuecard;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.doers.noqadmin.R;
import com.doers.noqadmin.models.UserModel;
import com.doers.noqadmin.utils.CaptureActivityAnyOrientation;
import com.doers.noqadmin.utils.DBHelper;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialog;
import com.shashank.sony.fancydialoglib.FancyAlertDialogListener;
import com.shashank.sony.fancydialoglib.Icon;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class issueCard extends AppCompatActivity {

    private static final int TRIGGER_AUTO_COMPLETE = 100;
    private static final long AUTO_COMPLETE_DELAY = 300;
    String login_user;
    DBHelper mydb;
    EditText EDT_MOBILENUM,EDT_CARDNUM;
    TextView TXT_NAME,TXT_WALLETBALANCE,TXT_USERCARDS;
    Button BTN_ISSUE;
    TableRow TR_AVAIL,TR_NOTAVAIL;
    private Handler handler;
    private String STR_MOBILENO,STR_CARDNO;
    private String scanContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_issuecard);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Issue Card");
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        EDT_MOBILENUM = findViewById(R.id.edt_mobileno);
        EDT_CARDNUM = findViewById(R.id.edt_cardno);
        TXT_NAME = findViewById(R.id.txt_username);
        TXT_WALLETBALANCE = findViewById(R.id.txt_walletbalance);
        TXT_USERCARDS = findViewById(R.id.txt_usercards);
        BTN_ISSUE = findViewById(R.id.btn_issue);
        TR_AVAIL = findViewById(R.id.msg_cardavail);
        TR_NOTAVAIL = findViewById(R.id.msg_cardnotavail);
        TR_AVAIL.setVisibility(View.GONE);
        TR_NOTAVAIL.setVisibility(View.GONE);
        mydb=new DBHelper(issueCard.this);
        UserModel userModel = new UserModel();
        userModel = mydb.getAllUsers();
        if(userModel.getUemail()==null){
            login_user="123";
        }else{
            login_user=String.valueOf(userModel.getUid());
        }

        EDT_MOBILENUM.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                handler.removeMessages(TRIGGER_AUTO_COMPLETE);
                handler.sendEmptyMessageDelayed(TRIGGER_AUTO_COMPLETE,
                        AUTO_COMPLETE_DELAY);
            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                if (msg.what == TRIGGER_AUTO_COMPLETE) {
                    if (!TextUtils.isEmpty(EDT_MOBILENUM.getText())) {
                        if (EDT_MOBILENUM.getText().toString().length()==10) {

                           STR_MOBILENO="";
                           EDT_MOBILENUM.setEnabled(false);
                          checkuser(EDT_MOBILENUM.getText().toString());
                        }
                    }
                }
                return false;
            }
        });

        EDT_CARDNUM.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // TODO Auto-generated method stub
                        {
                            IntentIntegrator scanIntegrator = new IntentIntegrator(issueCard.this);
                            scanIntegrator.setPrompt("Scan");
                            scanIntegrator.setBeepEnabled(true);
                            //The following line if you want QR code
//                            scanIntegrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
                            scanIntegrator.setCaptureActivity(CaptureActivityAnyOrientation.class);
                            scanIntegrator.setOrientationLocked(false);
                            scanIntegrator.setBarcodeImageEnabled(true);
                            scanIntegrator.initiateScan();
                            //  ScanDomn();
                        }
                    }
                });

        BTN_ISSUE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if(STR_MOBILENO.length()==10&&STR_CARDNO.length()>5)
               {issuecard();}
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult scanningResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (scanningResult != null) {
            if (scanningResult.getContents() != null) {
                scanContent = scanningResult.getContents();
                EDT_CARDNUM.setText(scanContent);
                checkcard(scanContent);
            }


        }else{
            Toast.makeText(this,"Nothing scanned",Toast.LENGTH_SHORT).show();
        }
    }
    public void checkcard(final String cardno){
        final ProgressDialog dlg = new ProgressDialog(this);
        dlg.setMessage("Validating Card...");
        dlg.setCancelable(false);
        dlg.show();



        String url = "http://noqapp.in/noq/prod/api/get_cardavailability/";

        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i
                        Log.i("VALUE",response.toString());
                        try {
                            JSONObject jobj = new JSONObject(response);
                            String STATUS = jobj.getString("status");
                            try{ dlg.dismiss();}
                            catch (Exception ignored){
                            }
                            if(Double.parseDouble(STATUS)==200){
                                STR_CARDNO=cardno;
                                TR_AVAIL.setVisibility(View.VISIBLE);
                                TR_NOTAVAIL.setVisibility(View.GONE);
                            }else{
                                TR_AVAIL.setVisibility(View.GONE);
                                TR_NOTAVAIL.setVisibility(View.VISIBLE);
                                STR_CARDNO="";
                                EDT_CARDNUM.setText("");

                            }
                        } catch (JSONException e) {
                            try{ dlg.dismiss();}
                            catch (Exception ignored){
                            }
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        try{ dlg.dismiss();}
                        catch (Exception ignored){
                        }
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map getParams()
            {
                Map<String, String> params = new HashMap<String, String>();
                params.put("cardno",cardno);
                return params;
            }
        };
        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);
    }
    public void checkuser(final String mobileno){
        final ProgressDialog dlg = new ProgressDialog(this);
        dlg.setMessage("Validating Mobile number...");
        dlg.setCancelable(false);
        dlg.show();



        String url = "http://noqapp.in/noq/prod/api/get_usercard/";

        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i
                        Log.i("VALUE",response.toString());
                        try {
                            JSONObject jobj = new JSONObject(response);
                            String STATUS = jobj.getString("userstatus");
                            try{ dlg.dismiss();}
                            catch (Exception ignored){
                            }
                            if(Double.parseDouble(STATUS)==200){
                                String Name = jobj.getString("fullname");
                                STR_MOBILENO = jobj.getString("mobile");
                                TXT_NAME.setText(Name+" ("+STR_MOBILENO+")");
                                String ledger =jobj.getString("ledgers").replace("null","");
                                if(ledger.isEmpty()){
                                    String Walletbalance = "\u20B9"+"0.00";
                                    TXT_WALLETBALANCE.setText(Walletbalance);
                                }else{
                                    JSONObject ledgerobj = new JSONObject(ledger);
                                    if(ledgerobj.length()>0){
                                        String Walletbalance = ledgerobj.getString("closing_balance");
                                        TXT_WALLETBALANCE.setText("\u20B9"+Walletbalance);
                                    }else{
                                        String Walletbalance = "\u20B9"+"0.00";
                                        TXT_WALLETBALANCE.setText(Walletbalance);
                                    }
                                }
                                String cards =jobj.getString("cards");
                                JSONArray cardsarr = new JSONArray(cards);
                                StringBuilder sb = new StringBuilder();
                                for(int k=0;k<cardsarr.length();k++){
                                    JSONObject cardobj = cardsarr.getJSONObject(k);
                                    String carddet= cardobj.getString("accesscode");
                                    sb.append(carddet); // str is already a String, no need for toString()
                                    sb.append(",\n");
                                }
                                if (sb.length() > 0) {
                                    sb.deleteCharAt(sb.length()-2);
                                }else{
                                    sb.append("-");
                                }
                                String sel_cat=sb.toString();
                                TXT_USERCARDS.setText(sel_cat);
                                EDT_MOBILENUM.setEnabled(false);
                            }else{
                                EDT_MOBILENUM.setEnabled(true);
                                FancyAlertDialog fnc =   new FancyAlertDialog.Builder(issueCard.this)
                                        .setTitle("NOQ User")
                                        .setBackgroundColor(Color.parseColor("#0D0135"))  //Don't pass R.color.colorvalue
                                        .setMessage("Invalid Mobile Number")
                                        .setPositiveBtnBackground(Color.parseColor("#FF4081"))  //Don't pass R.color.colorvalue
                                        .setPositiveBtnText("Ok")
                                        .setNegativeBtnText("Cancel")
                                        .setIcon(R.drawable.ic_block, Icon.Visible)
                                        .setAnimation(Animation.POP)
                                        .isCancellable(false)
                                        .OnNegativeClicked(new FancyAlertDialogListener() {
                                            @Override
                                            public void OnClick() {
                                                STR_MOBILENO="";
                                            }
                                        }).OnPositiveClicked(new FancyAlertDialogListener() {
                                            @Override
                                            public void OnClick() {
                                                EDT_MOBILENUM.setText("");
                                                STR_MOBILENO="";
                                            }
                                        })
                                        .build();


                            }
                        } catch (JSONException e) {
                            EDT_MOBILENUM.setEnabled(true);
                            try{ dlg.dismiss();}
                            catch (Exception ignored){
                            }
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        try{ dlg.dismiss();}
                        catch (Exception ignored){
                        }
                        EDT_MOBILENUM.setEnabled(true);
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map getParams()
            {
                Map<String, String> params = new HashMap<String, String>();
                params.put("mobilenumber",mobileno);
                return params;
            }
        };
        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);
    }
    public void issuecard(){
        final ProgressDialog dlg = new ProgressDialog(this);
        dlg.setMessage("Card Processing...");
        dlg.setCancelable(false);
        dlg.show();



        String url = "http://noqapp.in/noq/prod/api/newcard/";

        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i
                        Log.i("VALUE",response.toString());
                        try {
                            JSONObject jobj = new JSONObject(response);
                            String STATUS = jobj.getString("status");
                            String msg = jobj.getString("msg");
                            try{ dlg.dismiss();}
                            catch (Exception dsf){

                            }
                            new FancyAlertDialog.Builder(issueCard.this)
                                    .setTitle("NOQ ISSUE CARD")
                                    .setBackgroundColor(Color.parseColor("#0D0135"))  //Don't pass R.color.colorvalue
                                    .setMessage(msg)
                                    .setPositiveBtnBackground(Color.parseColor("#FF4081"))  //Don't pass R.color.colorvalue
                                    .setPositiveBtnText("Ok")
                                    .setNegativeBtnText("Cancel")
                                    .setIcon(R.drawable.ic_done, Icon.Visible)
                                    .setAnimation(Animation.POP)
                                    .isCancellable(false)
                                    .OnNegativeClicked(new FancyAlertDialogListener() {
                                        @Override
                                        public void OnClick() {
                                            Intent setIntent = new Intent(issueCard.this, issueCard.class);
                                            setIntent.addCategory(Intent.CATEGORY_HOME);
                                            setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                            startActivity(setIntent);
                                            finish();
                                        }
                                    }).OnPositiveClicked(new FancyAlertDialogListener() {
                                @Override
                                public void OnClick() {
                                    Intent setIntent = new Intent(issueCard.this, issueCard.class);
                                    setIntent.addCategory(Intent.CATEGORY_HOME);
                                    setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(setIntent);
                                    finish();
                                }
                            })
                                    .build();



//                        //Uncomment the below code to Set the message and title from the strings.xml file
//                           AlertDialog.Builder builder = new AlertDialog.Builder(TopUp.this);
//                           builder.setMessage(msg).setTitle("NOQ TOP UP")
//                                   .setCancelable(false)
//                                   .setPositiveButton("Close", new DialogInterface.OnClickListener() {
//                                       public void onClick(DialogInterface dialog, int id) {
//                                           Intent setIntent = new Intent(TopUp.this, TopUp.class);
//                                           setIntent.addCategory(Intent.CATEGORY_HOME);
//                                           setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                                           startActivity(setIntent);
//                                           finish();
//                                       }
//                                   });
//                           //Creating dialog box
//                           AlertDialog alert = builder.create();
//                           //Setting the title manually
//                           alert.setTitle("NOQ TOP UP");
//                           alert.show();
                        } catch (JSONException e) {
                            try{ dlg.dismiss();}
                            catch (Exception dsf){

                            }
                            e.printStackTrace();
                        }



                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        try{ dlg.dismiss();}
                        catch (Exception dsf){

                        }
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map getParams()
            {
                Map params = new HashMap();
                params.put("mobile",STR_MOBILENO);
                params.put("notes", "MOBILE");
                params.put("new_access_code", STR_CARDNO);

                return params;
            }

        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));    //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }
}

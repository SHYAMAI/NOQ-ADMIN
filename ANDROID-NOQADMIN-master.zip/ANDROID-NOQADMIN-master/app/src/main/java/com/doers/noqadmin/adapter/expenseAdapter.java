package com.doers.noqadmin.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.Color;
import android.text.SpannableString;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.view.ContextThemeWrapper;
import androidx.recyclerview.widget.RecyclerView;

import com.doers.noqadmin.ExpenseActivity;
import com.doers.noqadmin.R;
import com.doers.noqadmin.models.expenseModel;
import com.doers.noqadmin.utils.DBHelper;
import java.util.List;

import cn.nekocode.badge.BadgeDrawable;
import jp.shts.android.library.TriangleLabelView;


public class expenseAdapter extends RecyclerView.Adapter<expenseAdapter.ViewHolder> {

    private Context context;
    private List<expenseModel> personUtils;
    DBHelper mydb;

    public expenseAdapter(Context context, List personUtils) {
        this.context = context;
        this.personUtils = personUtils;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.expense_singleitem, parent, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.itemView.setTag(personUtils.get(position));
        expenseModel pu = personUtils.get(position);
        if(pu.getExpstatus().equalsIgnoreCase("SETTLED")){
            holder.statuspaid.setVisibility(View.VISIBLE);
            holder.statuspending.setVisibility(View.GONE);
}else{
            holder.statuspaid.setVisibility(View.GONE);
            holder.statuspending.setVisibility(View.VISIBLE);
}
        holder.exp_amnt.setText(" ₹"+pu.getExp_amount());
        holder.exp_category.setText(pu.getExp_categoryname());
        holder.exp_desc.setText(pu.getExp_desc());
        holder.exp_date.setText(pu.getExpsdate());
        holder.spent_user.setText("- "+pu.getExp_spentusername());

    }

    @Override
    public int getItemCount() {
        return personUtils.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView exp_amnt;
        public TextView exp_category,exp_desc,exp_date,spent_user;
private TriangleLabelView statuspaid,statuspending;
        public ViewHolder(View itemView) {
            super(itemView);
            statuspaid = itemView.findViewById(R.id.statuspaid);
            spent_user = itemView.findViewById(R.id.exp_extra);
            statuspending = itemView.findViewById(R.id.statuspending);
            exp_amnt = (TextView) itemView.findViewById(R.id.exp_amnt);
            exp_category = (TextView) itemView.findViewById(R.id.exp_category);
            exp_desc = (TextView) itemView.findViewById(R.id.exp_desc);
            exp_date = (TextView) itemView.findViewById(R.id.exp_date);
//            itemView.setOnLongClickListener(new View.OnLongClickListener() {
//                @Override
//                public boolean onLongClick(View view) {
//                    //Uncomment the below code to Set the message and title from the strings.xml file
//                    AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(context, R.style.DialogTheme));
//                    builder.setMessage("Are You Sure To Remove this Entry") .setTitle("Alert")
//
//                            .setCancelable(false)
//                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//                                public void onClick(DialogInterface dialog, int id) {
//                                    removeAt(getAdapterPosition());
//
//                                }
//                            })
//                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
//                                public void onClick(DialogInterface dialog, int id) {
//                                    //  Action for 'NO' Button
//                                    dialog.cancel();
//
//                                }
//                            });
//                    //Creating dialog box
//                    AlertDialog alert = builder.create();
//                    //Setting the title manually
//                    alert.setTitle("Alert");
//                    alert.show();
//                    return false;
//                }
//            });
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    expenseModel cpu = (expenseModel) view.getTag();

                    Toast.makeText(view.getContext(), cpu.getExp_category()+" is "+ cpu.getExp_amount(), Toast.LENGTH_SHORT).show();

                }
            });

        }
    }
    public void removeAt(int position) {
        mydb=new DBHelper(context);
        mydb.deleteExpense(personUtils.get(position).getExp_id());
        personUtils.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, personUtils.size());
        notifyDataSetChanged();
    }

}
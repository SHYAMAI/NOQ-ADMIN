package com.doers.noqadmin;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.doers.noqadmin.utils.CaptureActivityAnyOrientation;
import com.doers.noqadmin.utils.DBHelper;
import com.doers.noqadmin.models.UserModel;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.mikhaellopez.lazydatepicker.LazyDatePicker;
import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialog;
import com.shashank.sony.fancydialoglib.FancyAlertDialogListener;
import com.shashank.sony.fancydialoglib.Icon;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class userRegister extends AppCompatActivity {
    private static final int TRIGGER_AUTO_COMPLETE = 100;
    private static final long AUTO_COMPLETE_DELAY = 300;
    EditText EDT_MOBILENO,EDT_NAME,EDT_CARDNO,EDT_EMAIL,EDT_FLATNO,EDT_NOTES,EDT_TOPUP;
    LazyDatePicker EDT_DOB;
    Button BTN_100,BTN_200,BTN_500,BTN_1000,BTN_REGISTER;
    RadioButton RAD_MALE,RAD_FEMALE,RAD_CASH,RAD_CARD;

    String STR_MOBILENO,STR_NAME,STR_CARDNO,STR_EMAIL,STR_DOB,STR_FLATNO,STR_NOTES,STR_TOPUP,STR_GENDER,STR_PAYMODE;
private Handler handler;
    String scan_barcode_value,login_user;
    private String scanContent,scanFormat;
    DBHelper mydb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_register);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("User Register");
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        STR_DOB="01-01-1900";
        EDT_MOBILENO = findViewById(R.id.edt_mobileno);
        EDT_NAME = findViewById(R.id.edt_name);
        EDT_CARDNO = findViewById(R.id.edt_cardno);
        EDT_EMAIL = findViewById(R.id.edt_email);
        EDT_DOB = findViewById(R.id.edt_dob);
        EDT_FLATNO = findViewById(R.id.edt_flatno);
        EDT_NOTES = findViewById(R.id.edt_notes);
        EDT_TOPUP = findViewById(R.id.edt_topup);

        BTN_100 = findViewById(R.id.btn100);
        BTN_200 = findViewById(R.id.btn200);
        BTN_500 = findViewById(R.id.btn500);
        BTN_1000 = findViewById(R.id.btn1000);
        BTN_REGISTER = findViewById(R.id.btn_add);

        RAD_MALE = findViewById(R.id.radiomale);
        RAD_FEMALE = findViewById(R.id.radiofemale);
        RAD_CASH = findViewById(R.id.radiocash);
        RAD_CARD = findViewById(R.id.radiocard);

        RAD_MALE.setChecked(true);
        RAD_CASH.setChecked(true);
        STR_PAYMODE="Cash";
        STR_GENDER="Male";
        mydb=new DBHelper(userRegister.this);
        UserModel userModel = new UserModel();
        userModel = mydb.getAllUsers();
        if(userModel.getUemail()==null){
            login_user="123";
        }else{
            login_user=String.valueOf(userModel.getUid());

        }

        BTN_100.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EDT_TOPUP.setText("100");
            }
        });
        BTN_200.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EDT_TOPUP.setText("200");
            }
        });
        BTN_500.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EDT_TOPUP.setText("500");
            }
        });
        BTN_1000.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EDT_TOPUP.setText("1000");
            }
        });
        RAD_CASH.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    RAD_CARD.setChecked(false);
                    STR_PAYMODE="Cash";
                }
            }
        });

        RAD_CARD.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    RAD_CASH.setChecked(false);
                    STR_PAYMODE="Card";
                }
            }
        });
        RAD_MALE.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    RAD_FEMALE.setChecked(false);
                    STR_GENDER="Male";
                }
            }
        });

        RAD_FEMALE.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    RAD_MALE.setChecked(false);
                    STR_GENDER="Female";
                }
            }
        });
        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                if (msg.what == TRIGGER_AUTO_COMPLETE) {
                    if (!TextUtils.isEmpty(EDT_MOBILENO.getText())) {
                        if (EDT_MOBILENO.getText().toString().length()==10) {
                            checkuser(EDT_MOBILENO.getText().toString());
                        }
                    }
                }
                return false;
            }
        });

        EDT_MOBILENO.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                handler.removeMessages(TRIGGER_AUTO_COMPLETE);
                handler.sendEmptyMessageDelayed(TRIGGER_AUTO_COMPLETE,
                        AUTO_COMPLETE_DELAY);
            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        EDT_CARDNO.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // TODO Auto-generated method stub
                      {
                            IntentIntegrator scanIntegrator = new IntentIntegrator(userRegister.this);
                            scanIntegrator.setPrompt("Scan");
                            scanIntegrator.setBeepEnabled(true);
                            //The following line if you want QR code
//                            scanIntegrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
                            scanIntegrator.setCaptureActivity(CaptureActivityAnyOrientation.class);
                            scanIntegrator.setOrientationLocked(false);
                            scanIntegrator.setBarcodeImageEnabled(true);
                            scanIntegrator.initiateScan();
                           //  ScanDomn();
                        }
                    }
                });
        String sDate1="01/01/1945";
        String sDate2="01/01/2019";
        Date minDate = null;
        Date maxDate = null;
        try {
            minDate=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
            maxDate=new SimpleDateFormat("dd/MM/yyyy").parse(sDate2);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        EDT_DOB.setDateFormat(LazyDatePicker.DateFormat.DD_MM_YYYY);
        EDT_DOB.setMinDate(minDate);
        EDT_DOB.setMaxDate(maxDate);

        EDT_DOB.setOnDatePickListener(new LazyDatePicker.OnDatePickListener() {
            @Override
            public void onDatePick(Date dateSelected) {
                //...
                STR_DOB=dateSelected.toString();
            }
        });

        EDT_DOB.setOnDateSelectedListener(new LazyDatePicker.OnDateSelectedListener() {
            @Override
            public void onDateSelected(Boolean dateSelected) {
                //...
            }
        });
        BTN_REGISTER.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try{
                    if(!TextUtils.isEmpty(EDT_MOBILENO.getText())){
                        STR_MOBILENO=EDT_MOBILENO.getText().toString();
                    }else{
                        STR_MOBILENO="";

                    }
                }catch (Exception d){
                    STR_MOBILENO="";
                }
                try{
                    if(!TextUtils.isEmpty(EDT_NAME.getText())){
                            STR_NAME=EDT_NAME.getText().toString();
                    }else{
                        STR_NAME="";

                    }
                }catch (Exception sd){
                    STR_NAME="";
                }

                try{
                    if(!TextUtils.isEmpty(EDT_CARDNO.getText())){
                        STR_CARDNO=EDT_CARDNO.getText().toString();
                    }else{
                        STR_CARDNO="";

                    }
                }catch (Exception sd){
                    STR_CARDNO="";
                }
                try{
                    if(!TextUtils.isEmpty(EDT_EMAIL.getText())){
                        STR_EMAIL=EDT_EMAIL.getText().toString();
                    }else{
                        STR_EMAIL="";

                    }
                }catch (Exception sd){
                    STR_EMAIL="";
                }
                try{
                    if(!TextUtils.isEmpty(EDT_FLATNO.getText())){
                        STR_FLATNO=EDT_FLATNO.getText().toString();
                    }else{
                        STR_FLATNO="";

                    }
                }catch (Exception sd){
                    STR_FLATNO="";
                }
                try{
                    if(!TextUtils.isEmpty(EDT_NOTES.getText())){
                        STR_NOTES=EDT_NOTES.getText().toString();
                    }else{
                        STR_NOTES="";

                    }
                }catch (Exception sd){
                    STR_NOTES="";
                }

                try{
                    if(!TextUtils.isEmpty(EDT_TOPUP.getText())){
                        STR_TOPUP=EDT_TOPUP.getText().toString();
                    }else{
                        STR_TOPUP="";

                    }
                }catch (Exception sd){
                    STR_TOPUP="";
                }
                if(STR_MOBILENO==null||STR_CARDNO==null||STR_TOPUP==null||STR_MOBILENO==""||STR_CARDNO==""||STR_TOPUP==""){
                    Toast.makeText(userRegister.this, "Invalid Mobile Number Try Again", Toast.LENGTH_SHORT).show();
                }else{
                    BTN_REGISTER.setEnabled(false);
                    add_customer();
                }
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult scanningResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (scanningResult != null) {
            if (scanningResult.getContents() != null) {
                scanContent = scanningResult.getContents();
                scanFormat = scanningResult.getFormatName();
                scan_barcode_value =scanContent;
                EDT_CARDNO.setText(scan_barcode_value);
            }


        }else{
            Toast.makeText(this,"Nothing scanned",Toast.LENGTH_SHORT).show();
        }
    }
    public void checkuser(final String mobileno){
        final ProgressDialog dlg = new ProgressDialog(this);
        dlg.setMessage("Validating Mobile number...");
        dlg.setCancelable(false);
        dlg.show();



        String url = "http://noqapp.in/noq/prod/api/check_user/";

        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i
                        Log.i("VALUE",response.toString());
                        try {
                            JSONObject jobj = new JSONObject(response);
                            String STATUS = jobj.getString("status");
                            String msg = jobj.getString("msg");
                            try{ dlg.dismiss();}
                            catch (Exception ignored){
                            }
                            if(Double.parseDouble(STATUS)==200){
                                STR_MOBILENO=EDT_MOBILENO.getText().toString();
                            }else{

                              FancyAlertDialog fnc =   new FancyAlertDialog.Builder(userRegister.this)
                                        .setTitle("NOQ User")
                                        .setBackgroundColor(Color.parseColor("#0D0135"))  //Don't pass R.color.colorvalue
                                        .setMessage(msg)
                                        .setPositiveBtnBackground(Color.parseColor("#FF4081"))  //Don't pass R.color.colorvalue
                                        .setPositiveBtnText("Ok")
                                      .setNegativeBtnText("Cancel")
                                      .setIcon(R.drawable.ic_block,Icon.Visible)
                                      .setAnimation(Animation.POP)
                                        .isCancellable(false)
                                       .OnNegativeClicked(new FancyAlertDialogListener() {
                                          @Override
                                          public void OnClick() {
                                              STR_MOBILENO="";
                                          }
                                      }).OnPositiveClicked(new FancyAlertDialogListener() {
                                            @Override
                                            public void OnClick() {
                                                EDT_MOBILENO.setText("");
                                                STR_MOBILENO="";
                                                 }
                                        })
                                        .build();


//
//                                //Uncomment the below code to Set the message and title from the strings.xml file
//                                AlertDialog.Builder builder = new AlertDialog.Builder(userRegister.this);
//                                builder.setMessage(msg).setTitle("NOQ User")
//                                        .setCancelable(false)
//                                        .setPositiveButton("Enter New Mobile Number", new DialogInterface.OnClickListener() {
//                                            public void onClick(DialogInterface dialog, int id) {
//                                                dialog.dismiss();
//                                                EDT_MOBILENO.setText("");
//                                                STR_MOBILENO="";
//                                            }
//                                        });
//                                //Creating dialog box
//                                AlertDialog alert = builder.create();
//                                //Setting the title manually
//                                alert.setTitle("NOQ User");
//                                alert.show();
                            }
                        } catch (JSONException e) {
                            try{ dlg.dismiss();}
                            catch (Exception ignored){
                            }
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        try{ dlg.dismiss();}
                        catch (Exception ignored){
                        }
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map getParams()
            {
                Map<String, String> params = new HashMap<String, String>();
                params.put("mobilenumber",mobileno);
                return params;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));  //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);
    }

    public void add_customer(){
        final ProgressDialog dlg = new ProgressDialog(this);
        dlg.setMessage("Customer Add Processing...");
        dlg.setCancelable(false);
        dlg.show();
        String url = "http://noqapp.in/noq/prod/api/add_customerforapp/";
        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i
                        Log.i("VALUE",response.toString());
                        try {
                            JSONObject jobj = new JSONObject(response);
                            final String STATUS = jobj.getString("status");
                            String msg = jobj.getString("msg");
                            try{ dlg.dismiss();}
                            catch (Exception dsf){
                            }

                            new FancyAlertDialog.Builder(userRegister.this)
                                    .setTitle("NOQ Add User")
                                    .setBackgroundColor(Color.parseColor("#0D0135"))  //Don't pass R.color.colorvalue
                                    .setMessage(msg)
                                    .setPositiveBtnBackground(Color.parseColor("#FF4081"))  //Don't pass R.color.colorvalue
                                    .setPositiveBtnText("Ok")
                                    .setNegativeBtnText("Cancel")
                                    .setIcon(R.drawable.ic_done,Icon.Visible)
                                    .setAnimation(Animation.POP)
                                    .isCancellable(false)
                                    .OnNegativeClicked(new FancyAlertDialogListener() {
                                        @Override
                                        public void OnClick() {
                                            if(Double.parseDouble(STATUS)==200){
                                                Intent setIntent = new Intent(userRegister.this, userRegister.class);
                                                setIntent.addCategory(Intent.CATEGORY_HOME);
                                                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                                startActivity(setIntent);
                                                finish();
                                            }else{
                                            }
                                        }
                                    }).OnPositiveClicked(new FancyAlertDialogListener() {
                                        @Override
                                        public void OnClick() {
                                            if(Double.parseDouble(STATUS)==200){
                                                Intent setIntent = new Intent(userRegister.this, userRegister.class);
                                                setIntent.addCategory(Intent.CATEGORY_HOME);
                                                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                                startActivity(setIntent);
                                                finish();
                                            }else{
                                            }
                                        }
                                    })
                                    .build();


//
////Uncomment the below code to Set the message and title from the strings.xml file
//                                AlertDialog.Builder builder = new AlertDialog.Builder(userRegister.this);
//                                builder.setMessage(msg).setTitle("NOQ Add User")
//                                        .setCancelable(false)
//                                        .setPositiveButton("Close", new DialogInterface.OnClickListener() {
//                                            public void onClick(DialogInterface dialog, int id) {
//                                                if(Double.parseDouble(STATUS)==200){
//                                                    Intent setIntent = new Intent(userRegister.this, userRegister.class);
//                                                    setIntent.addCategory(Intent.CATEGORY_HOME);
//                                                    setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                                                    startActivity(setIntent);
//                                                    finish();
//                                                }else{
//                                                }
//                                            }
//                                        });
//                                //Creating dialog box
//                                AlertDialog alert = builder.create();
//                                //Setting the title manually
//                                alert.setTitle("NOQ Add User");
//                                alert.show();
                        } catch (JSONException e) {
                            try{ dlg.dismiss();}
                            catch (Exception dsf){
                            }
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        try{ dlg.dismiss();}
                        catch (Exception dsf){
                        }
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map getParams()
            {
                Map<String, String> params = new HashMap<>();
                params.put("accesscard",STR_CARDNO);
                params.put("mobile", STR_MOBILENO);
                params.put("fullname", STR_NAME);
                params.put("email", STR_EMAIL);
                params.put("flat_no", STR_FLATNO);
                params.put("notes", STR_NOTES);
                params.put("dob", STR_DOB);
                params.put("gender", STR_GENDER);
                params.put("paid_by", STR_PAYMODE);
                params.put("topup", STR_TOPUP);
                params.put("managerid", login_user);
                return params;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT)); //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);
    }
}

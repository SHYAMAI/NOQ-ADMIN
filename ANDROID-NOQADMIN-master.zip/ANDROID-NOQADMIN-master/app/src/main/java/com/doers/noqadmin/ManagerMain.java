package com.doers.noqadmin;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.text.SpannableString;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.doers.noqadmin.grn.GrnActivity;
import com.doers.noqadmin.issuecard.issueCard;
import com.doers.noqadmin.stockupdate.stockUpdate;
import com.doers.noqadmin.utils.DBHelper;
import com.doers.noqadmin.models.UserModel;
import com.google.android.material.navigation.NavigationView;
import com.pitt.library.fresh.FreshDownloadView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

import cn.nekocode.badge.BadgeDrawable;
import pub.devrel.easypermissions.EasyPermissions;


public class ManagerMain extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    DBHelper mydb;
    TextView usernametext,mailtext;
    TextView TodayCash;
    TextView TodayCard;
    TextView TodayUser;
    TextView TotalUser;
    TextView TodayUnSettled;
    TextView TotalUnSettled;
private String login_user;
    FreshDownloadView Progress;
    AlertDialog alertDialog;
    private static final int WRITE_REQUEST_CODE = 300;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        StrictMode.VmPolicy.Builder builder1 = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder1.build());
        View navView =  navigationView.inflateHeaderView(R.layout.nav_header_main);
        CheckVerison();
        usernametext = navView.findViewById(R.id.user_nametext);
        mailtext = navView.findViewById(R.id.user_mailtext);
        mydb=new DBHelper(ManagerMain.this);
        UserModel userModel = new UserModel();
        userModel = mydb.getAllUsers();
        if(userModel.getUemail()==null){
            login_user="123";
        }else{
            String name =String.valueOf(userModel.getUname());
            String email =String.valueOf(userModel.getUemail());
            usernametext.setText(name);
            mailtext.setText(email);
            login_user=String.valueOf(userModel.getUid());
        }
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
         TodayCash = findViewById(R.id.managerdash_todaycash);
         TodayCard = findViewById(R.id.managerdash_todaycard);
         TodayUser = findViewById(R.id.managerdash_todayuser);
         TotalUser = findViewById(R.id.managerdash_totaluser);
         TodayUnSettled = findViewById(R.id.managerdash_todayunsettled);
         TotalUnSettled = findViewById(R.id.managerdash_totalunsettled);
        loaddash();

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_manager, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_logout) {
                     mydb.deleteUSer(1);

            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);

            finish();
            return true;
        }
        else if (id == R.id.action_refresh) {
            loaddash();

            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        if (id == R.id.nav_topup) {
            // Handle the camera action
            Intent intent = new Intent(getApplicationContext(), TopUp.class);
            startActivity(intent);
        } else if (id == R.id.nav_newuser) {
            Intent intent = new Intent(getApplicationContext(), userRegister.class);
            startActivity(intent);
        }
        else if (id == R.id.nav_expenses) {
            Intent intent = new Intent(getApplicationContext(), ExpenseActivity.class);
            startActivity(intent);
        }
        else if (id == R.id.nav_stockupdate) {
            Intent intent = new Intent(getApplicationContext(), stockUpdate.class);
            startActivity(intent);
        } else if (id == R.id.nav_grn) {
            // Handle the camera action
            Intent intent = new Intent(getApplicationContext(), GrnActivity.class);
            startActivity(intent);
        }else if (id == R.id.nav_issuecard) {
            // Handle the camera action
            Intent intent = new Intent(getApplicationContext(), issueCard.class);
            startActivity(intent);
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    public void loaddash(){
        String url = "http://noqapp.in/noq/prod/api/dashboard_app/";

        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //hiding the progressbar after completionLog.i

                        Log.i("VALUE",response.toString());

                        try {
                            JSONObject jarray = new JSONObject(response);

                            String todaycash,todaycard,todayuser,totaluser,todayunsettled,todaysettled,totalunsettled,totalsettled;

                            todaycash=jarray.getString("today_cash_topup").replace("null","0.00");
                            todaycard=jarray.getString("today_card_topup").replace("null","0.00");
                            todayuser=jarray.getString("today_user").replace("null","0");
                            totaluser=jarray.getString("total_user").replace("null","0");
                            todayunsettled=jarray.getString("today_settlement").replace("null","0.00");
                            totalunsettled=jarray.getString("balance").replace("null","0.00");

                            TodayCash.setText("₹ "+getdecimal(todaycash));
                            TodayCard.setText("₹ "+getdecimal(todaycard));
                            TodayUser.setText(todayuser);
                            TotalUser.setText(totaluser);
                            TodayUnSettled.setText("₹ "+getdecimal(todayunsettled));
                            TotalUnSettled.setText("₹ "+getdecimal(totalunsettled));

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        try{ }
                        catch (Exception dsf){

                        }
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map getParams()
            {
                Map params = new HashMap();
                params.put("loginid", login_user);

                return params;
            }

        };
        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }
    private String getdecimal(String data){
        System.out.println("string liters of petrol putting in preferences is "+data);
        Float litersOfPetrol=Float.parseFloat(data);
        DecimalFormat df = new DecimalFormat("#,##,##0.00");
        df.setMaximumFractionDigits(2);
        data = df.format(litersOfPetrol);
        System.out.println("liters of petrol before putting in editor : "+data);
        return data;
    }
    public void CheckUpdate() {
        // new LongOperation().execute("APKURL");

        if (CheckForSDCard.isSDCardPresent()) {

            //check if app has permission to write to the external storage.
            if (EasyPermissions.hasPermissions(ManagerMain.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                //Get the URL entered
                new LongOperation().execute("http://noqapp.in/noqadmin.apk");

            } else {
                //If permission is not present request for the same.
                EasyPermissions.requestPermissions(ManagerMain.this, getString(R.string.write_file), WRITE_REQUEST_CODE, Manifest.permission.READ_EXTERNAL_STORAGE);
            }


        } else {
            Toast.makeText(getApplicationContext(),
                    "SD Card not found", Toast.LENGTH_LONG).show();

        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, ManagerMain.this);
    }
    public static class CheckForSDCard {
        //Method to Check If SD Card is mounted or not
        public static boolean isSDCardPresent() {
            if (Environment.getExternalStorageState().equals(

                    Environment.MEDIA_MOUNTED)) {
                return true;
            }
            return false;
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class LongOperation extends AsyncTask<String, Void, String> {
        //    private ProgressDialog progressDialog;
        @Override
        protected String doInBackground(String... params) {
            try {
                String extStorageDirectory = ManagerMain.this.getExternalFilesDir(null).getAbsolutePath().toString();
                File folder = new File(extStorageDirectory, "NOQ");
                folder.mkdir();
                try {
                    File file1 = new File(folder, "noqadmin.apk");
                    file1.delete();
                }catch (Exception sf){

                }
                File file = new File(folder, "noqadmin." + "apk");
                try {
                    file.createNewFile();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                FileOutputStream f = new FileOutputStream(file);
                URL u = new URL(params[0]);
                HttpURLConnection c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("GET");
                //c.setDoOutput(true);
                c.connect();
                int lengthOfFile = c.getContentLength();

                InputStream in = c.getInputStream();
                byte[] buffer = new byte[1024];
                int len1 = 0;
                long total = 0;
                while ((len1 = in.read(buffer)) > 0) {
                    f.write(buffer, 0, len1);
                    total += len1;
                    float Percent = (total * 100) / lengthOfFile;

                    int ht = (int) Percent;
                    publishProgress(ht);
                }

                f.close();
            } catch (Exception e) {
                System.out.println("exception in DownloadFile: --------" + e.toString());
//                Progress.showDownloadError();
                e.printStackTrace();
            }
            return "Executed";
        }

        private void publishProgress(int s) {
            //   progressDialog.setProgress(s);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Progress.upDateProgress(s);
                    //Your code
                }
            });
        }

        @Override
        protected void onPostExecute(String result) {
            alertDialog.dismiss();

            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(Uri.fromFile(new File(ManagerMain.this.getExternalFilesDir(null).getAbsolutePath() + "/noq/" + "noqadmin.apk")), "application/vnd.android.package-archive");
                    startActivity(intent);       //Do something after 100ms
                }
            }, 2000);


        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            LayoutInflater li = LayoutInflater.from(ManagerMain.this);
            View promptsView = li.inflate(R.layout.dialog_downloading, null);
            Progress= promptsView.findViewById (R.id.pitt);

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                    ManagerMain.this);
            // set prompts.xml to alertdialog builder
            alertDialogBuilder.setView(promptsView);

            // set dialog message
            alertDialogBuilder
                    .setCancelable(false);
            // create alert dialog
            alertDialog = alertDialogBuilder.create();

            // show it
            alertDialog.show();
        }
    }

    public void CheckVerison(){
        String url = "http://noqapp.in/noq/prod/api/get_adminversion/";
        //creating a string request to send request to the url
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.i("VALUE",response.toString());
                        try {
                            int versionCode = BuildConfig.VERSION_CODE;
                            JSONObject jobj = new JSONObject(response);
                            String VERSION = jobj.getString("version");

                            if(Double.parseDouble(VERSION)==Double.parseDouble(String.valueOf(versionCode))){
                                Log.i("Uptodate;",VERSION);

                            }else{
                                CheckUpdate();
                            }



                        } catch (JSONException e) {

                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs

                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }){

            @Override
            protected Map getParams()
            {
                Map<String, String> params = new HashMap<String, String>();
                params.put("version", "1.8");

                return params;
            }

        };
        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);

    }
}

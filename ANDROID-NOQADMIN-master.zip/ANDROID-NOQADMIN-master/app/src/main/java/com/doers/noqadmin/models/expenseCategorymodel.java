package com.doers.noqadmin.models;

public class expenseCategorymodel  {

    String strCode,strDesc;

public expenseCategorymodel(String strCode, String strDesc) {
        this.strCode = strCode;
        this.strDesc = strDesc;
    }

    public String getStrCode() {
        return strCode;
    }

    public void setStrCode(String strCode) {
        this.strCode = strCode;
    }

    public String getStrDesc() {
        return strDesc;
    }

    public void setStrDesc(String strDesc) {
        this.strDesc = strDesc;
    }
    // add this line
    @Override
    public String toString() {
        return getStrDesc();
    }
}
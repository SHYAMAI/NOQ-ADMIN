package com.doers.noqadmin;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.doers.noqadmin.utils.ApiCall;
import com.doers.noqadmin.utils.AutoSuggestAdapter;
import com.doers.noqadmin.utils.CustomerModel;
import com.doers.noqadmin.utils.DBHelper;
import com.doers.noqadmin.models.UserModel;
import com.otaliastudios.autocomplete.Autocomplete;
import com.shashank.sony.fancydialoglib.Animation;
import com.shashank.sony.fancydialoglib.FancyAlertDialog;
import com.shashank.sony.fancydialoglib.FancyAlertDialogListener;
import com.shashank.sony.fancydialoglib.Icon;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;
import androidx.appcompat.widget.Toolbar;

import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;


public class TopUp extends AppCompatActivity {
    private Autocomplete maleFemaleAutocomplete;
    private String cardid;
    DBHelper mydb;


    private static final int TRIGGER_AUTO_COMPLETE = 100;
    private static final long AUTO_COMPLETE_DELAY = 300;
    private Handler handler;
    private AutoSuggestAdapter autoSuggestAdapter;
    AppCompatAutoCompleteTextView autoCompleteTextView;
    TextView selectedText,walletbalance;
    LinearLayout showcontent;
    RadioButton CASHBTN,CARDBTN;
    Button BTN100,BTN200,BTN500,BTN1000,BTN_TOPUP;
    EditText EDT_TOPUP,EDT_DESC;
String customer_id,customer_name,wallet_balance,description,paymode,topup_amount,login_user,mobile,email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_up);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("TOP UP");
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
       showcontent =findViewById(R.id.showcontent);
         autoCompleteTextView =   findViewById(R.id.topbar);
        selectedText = findViewById(R.id.selectext);
        walletbalance = findViewById(R.id.walletbalance);
        CASHBTN = (RadioButton) findViewById(R.id.radiocash);
        CARDBTN = (RadioButton) findViewById(R.id.radiocard);
        BTN100 = (Button) findViewById(R.id.btn100);
        BTN200 = (Button) findViewById(R.id.btn200);
        BTN500 = (Button) findViewById(R.id.btn500);
        BTN1000 = (Button) findViewById(R.id.btn1000);
        EDT_TOPUP = (EditText) findViewById(R.id.topupedit);
        EDT_DESC = (EditText) findViewById(R.id.txtdesc);
        BTN_TOPUP = (Button) findViewById(R.id.btntopup);

        showcontent.setVisibility(View.INVISIBLE);
        description="_";
        mydb=new DBHelper(TopUp.this);
        BTN_TOPUP.setEnabled(true);

        UserModel userModel = new UserModel();
        userModel = mydb.getAllUsers();
        if(userModel.getUemail()==null){
            login_user="123";
        }else{
            login_user=String.valueOf(userModel.getUid());

        }

        BTN100.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EDT_TOPUP.setText("100");
            }
        });
        BTN200.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EDT_TOPUP.setText("200");
            }
        });
        BTN500.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EDT_TOPUP.setText("500");
            }
        });
        BTN1000.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EDT_TOPUP.setText("1000");
            }
        });
        BTN_TOPUP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               try{
                   if(!TextUtils.isEmpty(EDT_DESC.getText())){
                       description=EDT_DESC.getText().toString();
                   }else{
                       description="_";
                   }

               }catch (Exception d){
                   description="_";
               }
               try{
                   if(!TextUtils.isEmpty(EDT_TOPUP.getText())){
                       if(Double.parseDouble(EDT_TOPUP.getText().toString())>0){
                           topup_amount=EDT_TOPUP.getText().toString();
                       }else{
                           topup_amount="0";
                       }
                   }

               }catch (Exception sd){
                   topup_amount="0";

               }
               if(topup_amount.equalsIgnoreCase("0")) {
                   Toast.makeText(TopUp.this, "Invalid Amount", Toast.LENGTH_SHORT).show();
               }else{
                   BTN_TOPUP.setEnabled(false);
                   topup();
                   }


            }
        });
        CASHBTN.setChecked(true);
        paymode="Cash";

        CARDBTN.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
if(isChecked){
    CASHBTN.setChecked(false);
    paymode="Card";
}
            }
        });

        CASHBTN.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    CARDBTN.setChecked(false);
                    paymode="Cash";
                }
            }
        });
        List<CustomerModel> stringList = new ArrayList<>();
        autoSuggestAdapter = new AutoSuggestAdapter(TopUp.this,android.R.layout.simple_dropdown_item_1line,stringList);
        autoCompleteTextView.setThreshold(2);
        autoCompleteTextView.setAdapter(autoSuggestAdapter);
        autoCompleteTextView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view,
                                            int position, long id) {
                        CustomerModel cim = autoSuggestAdapter.getItem(position);
                        selectedText.setText(cim.getName()+" ("+cim.getMobile()+")");
                        walletbalance.setText("\u20B9"+cim.getWalletbalance());
                        showcontent.setVisibility(View.VISIBLE);
                        customer_id=cim.getId();
                        customer_name=cim.getName();
                        wallet_balance=cim.getWalletbalance();
                        mobile=cim.getMobile();
                        email=cim.getEmail();
                    }
                });

        autoCompleteTextView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int
                    count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before,
                                      int count) {
                handler.removeMessages(TRIGGER_AUTO_COMPLETE);
                handler.sendEmptyMessageDelayed(TRIGGER_AUTO_COMPLETE,
                        AUTO_COMPLETE_DELAY);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                if (msg.what == TRIGGER_AUTO_COMPLETE) {
                    if (!TextUtils.isEmpty(autoCompleteTextView.getText())) {
                        if (!autoCompleteTextView.getText().toString().contains(" - ")) {
                            makeApiCall(autoCompleteTextView.getText().toString());

                        }
                    }
                }
                return false;
            }
        });
        //Setting up the adapter for AutoSuggest

    }

    private void makeApiCall(String text) {
        ApiCall.make(this, text, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("Resp:",response);
                //parsing logic, please change it as per your requirement
                List<CustomerModel> stringList = new ArrayList<>();
                try {
                    JSONArray responsejson = new JSONArray(response);
                    for (int i = 0; i < responsejson.length(); i++) {
                        JSONObject responseObject = responsejson.getJSONObject(i);

                        String id, name, mobile,access_code,walletbalance,email;
                         id=responseObject.getString("id");
                        name=responseObject.getString("fullname");
                        mobile=responseObject.getString("mobile");
                        email=responseObject.getString("email");
                        access_code=responseObject.getString("access_code");
                        walletbalance=responseObject.getString("balance");
                        stringList.add(new CustomerModel(id, name, mobile,access_code,walletbalance,email));
                    }


//
//                        JSONObject responseObject = new JSONObject(response);
//                    JSONArray array = responseObject.getJSONArray("results");
//                    for (int i = 0; i < array.length(); i++) {
//                        JSONObject row = array.getJSONObject(i);
//                        stringList.add(row.getString("trackName"));
//                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                //IMPORTANT: set data here and notify
                autoSuggestAdapter = new AutoSuggestAdapter(TopUp.this,android.R.layout.simple_dropdown_item_1line,stringList);
                autoCompleteTextView.setThreshold(2);
                autoCompleteTextView.setAdapter(autoSuggestAdapter);
                autoSuggestAdapter.notifyDataSetChanged();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
    }
   public void topup(){
    final ProgressDialog dlg = new ProgressDialog(this);
    dlg.setMessage("Recharge Processing...");
    dlg.setCancelable(false);
    dlg.show();



   String url = "http://noqapp.in/noq/prod/api/topup_app/";

    //creating a string request to send request to the url
    StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
            new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    //hiding the progressbar after completionLog.i
                    Log.i("VALUE",response.toString());
                    try {
                        JSONObject jobj = new JSONObject(response);
                       String STATUS = jobj.getString("status");
                       String msg = jobj.getString("msg");
                          try{ dlg.dismiss();}
                          catch (Exception dsf){

                          }
                        new FancyAlertDialog.Builder(TopUp.this)
                                .setTitle("NOQ Top Up")
                                .setBackgroundColor(Color.parseColor("#0D0135"))  //Don't pass R.color.colorvalue
                                .setMessage(msg)
                                .setPositiveBtnBackground(Color.parseColor("#FF4081"))  //Don't pass R.color.colorvalue
                                .setPositiveBtnText("Ok")
                                .setNegativeBtnText("Cancel")
                                .setIcon(R.drawable.ic_done, Icon.Visible)
                                .setAnimation(Animation.POP)
                                .isCancellable(false)
                                .OnNegativeClicked(new FancyAlertDialogListener() {
                                    @Override
                                    public void OnClick() {
                                        Intent setIntent = new Intent(TopUp.this, TopUp.class);
                                        setIntent.addCategory(Intent.CATEGORY_HOME);
                                        setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(setIntent);
                                        finish();
                                    }
                                }).OnPositiveClicked(new FancyAlertDialogListener() {
                            @Override
                            public void OnClick() {
                                Intent setIntent = new Intent(TopUp.this, TopUp.class);
                                setIntent.addCategory(Intent.CATEGORY_HOME);
                                setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(setIntent);
                                finish();
                            }
                        })
                                .build();



//                        //Uncomment the below code to Set the message and title from the strings.xml file
//                           AlertDialog.Builder builder = new AlertDialog.Builder(TopUp.this);
//                           builder.setMessage(msg).setTitle("NOQ TOP UP")
//                                   .setCancelable(false)
//                                   .setPositiveButton("Close", new DialogInterface.OnClickListener() {
//                                       public void onClick(DialogInterface dialog, int id) {
//                                           Intent setIntent = new Intent(TopUp.this, TopUp.class);
//                                           setIntent.addCategory(Intent.CATEGORY_HOME);
//                                           setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                                           startActivity(setIntent);
//                                           finish();
//                                       }
//                                   });
//                           //Creating dialog box
//                           AlertDialog alert = builder.create();
//                           //Setting the title manually
//                           alert.setTitle("NOQ TOP UP");
//                           alert.show();
                    } catch (JSONException e) {
                        try{ dlg.dismiss();}
                        catch (Exception dsf){

                        }
                        e.printStackTrace();
                    }



                }
            },
            new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    //displaying the error in toast if occurrs
                    try{ dlg.dismiss();}
                    catch (Exception dsf){

                    }
                    Toast.makeText(getApplicationContext(), "Error"+error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }){

        @Override
        protected Map getParams()
        {
            Map params = new HashMap();
            params.put("mobilenumber",mobile);
            params.put("paid_by", paymode);
            params.put("fullname", customer_name);
            params.put("mobile", mobile);
            params.put("email", email);
            params.put("notes", description);
            params.put("wallet", wallet_balance);
            params.put("topup", topup_amount);
            params.put("managerid", login_user);

            return params;
        }

    };
       stringRequest.setRetryPolicy(new DefaultRetryPolicy(
               10000,
               0,
               DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
    //creating a request queue
    RequestQueue requestQueue = Volley.newRequestQueue(this);
    //adding the string request to request queue
    requestQueue.add(stringRequest);

}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_topup, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_reset) {
            Intent intent = new Intent(TopUp.this, TopUp.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);

            finish();  return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        Log.d("CDA", "onBackPressed Called");
        Intent setIntent = new Intent(TopUp.this, LoginActivity.class);
        setIntent.addCategory(Intent.CATEGORY_HOME);
        setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(setIntent);
    }
}
